(function() {
	alert("This is just some other file.");
})();
package plugin.arcwolf.blockdoor;

// Ported from Hey0 by ArcWolf to Bukkit with permission from Ho0ber

import java.util.logging.Level;
import java.util.logging.Logger;

import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

import plugin.arcwolf.blockdoor.Doors.HDoorHelper;
import plugin.arcwolf.blockdoor.Doors.SingleStateDoorHelper;
import plugin.arcwolf.blockdoor.Doors.TwoStateDoorHelper;
import plugin.arcwolf.blockdoor.Triggers.RedTrigHelper;
import plugin.arcwolf.blockdoor.Triggers.TriggerHelper;
import plugin.arcwolf.blockdoor.Utils.DataWriter;
import plugin.arcwolf.blockdoor.Utils.ItemCodesHelper;
import plugin.arcwolf.blockdoor.Zones.ZoneHelper;
import plugin.arcwolf.blockdoor.commands.CommandHandler;
import plugin.arcwolf.blockdoor.listeners.BlockDoorBlockListener;
import plugin.arcwolf.blockdoor.listeners.BlockDoorEntityListener;
import plugin.arcwolf.blockdoor.listeners.BlockDoorPlayerListener;
import plugin.arcwolf.blockdoor.listeners.ZoneMobWatcher;

// Permissions Imports
import ru.tehkode.permissions.bukkit.PermissionsEx;
import org.anjocaido.groupmanager.GroupManager;
import com.nijikokun.bukkit.Permissions.Permissions;

public class BlockDoor extends JavaPlugin {

    public static final Logger LOGGER = Logger.getLogger("Minecraft.BlockDoor");

    public static enum Locks {
        LOCKED, UNLOCKED
    }
    
    public static enum Types {
        TOGGLE, OPEN, CLOSE, DISABLED
    }
    
    public Server server;
    private BukkitScheduler scheduler;
    public static BlockDoor plugin;

    private GroupManager groupManager;
    private Permissions permissionsPlugin;
    private PermissionsEx permissionsExPlugin;
    private de.bananaco.bpermissions.imp.Permissions bPermissions;

    public DataWriter datawriter;
    public DListerHelper dlisterhelper;
    public ItemCodesHelper itemcodeshelper;

    public CommandHandler commandhandler;

    public ZoneHelper zonehelper;

    public TriggerHelper triggerhelper;
    public RedTrigHelper redtrighelper;

    public HDoorHelper hdoorhelper;
    public TwoStateDoorHelper twostatedoorhelper;
    public SingleStateDoorHelper singlestatedoorhelper;
    private String pluginName;
    private String pluginVersion;

    @Override
    public void onEnable() {
        
        plugin = this;
        
        server = this.getServer();
        scheduler = server.getScheduler();
       
        datawriter = new DataWriter();
        dlisterhelper = new DListerHelper();
        itemcodeshelper = new ItemCodesHelper();

        commandhandler = new CommandHandler();

        zonehelper = new ZoneHelper();

        triggerhelper = new TriggerHelper();
        redtrighelper = new RedTrigHelper();

        hdoorhelper = new HDoorHelper();
        twostatedoorhelper = new TwoStateDoorHelper();
        singlestatedoorhelper = new SingleStateDoorHelper();

        BlockDoorBlockListener blockListener = new BlockDoorBlockListener();
        BlockDoorPlayerListener playerListener = new BlockDoorPlayerListener();
        BlockDoorEntityListener entityListener = new BlockDoorEntityListener();

        PluginDescriptionFile pdfFile = getDescription();
        PluginManager pm = server.getPluginManager();

        pluginName = pdfFile.getName();
        pluginVersion = pdfFile.getVersion();
        
        // Used with regular triggers, zones and dinfo
        // Also, protection from commands being abused with teleportation 
        pm.registerEvents(playerListener, this);

        // For use with redstone triggers and twostate doors
        pm.registerEvents(blockListener, this);
        
        // Prevent endermen pickup/place, explosions and leaves decaying with twostate doors
        pm.registerEvents(entityListener, this);

        datawriter.initFile();
        getPermissionsPlugin(); //Test for permissions        
        LOGGER.info(pluginName + " version " + pluginVersion + " is enabled!");

        // set up the thread for zone detection
        scheduler.scheduleSyncRepeatingTask(this, new ZoneMobWatcher(), 10, 10);
    }

    @Override
    public void onDisable() {
        scheduler.cancelTasks(this);
        LOGGER.info(pluginName + " saving database...");
        twostatedoorhelper.lock(); // Lock all doors in database.
        int count = datawriter.saveDatabase(); // Resave the database before quit.
        if (count != -1)
            LOGGER.info(pluginName + " Save Completed. " + count + " object(s) saved.");
        else
            LOGGER.log(Level.SEVERE, datawriter.getDoorsLoc() + " Does not exist! Save failed!");

        LOGGER.info(pluginName + " version " + pluginVersion + " is disabled!");
    }

    //return a world object from a world name string
    public World getWorld(String worldname) {
        return server.getWorld(worldname);
    }

    //test for a players permissions
    public boolean playerHasPermission(Player player, String command) {
        getPermissionsPlugin();
        if (groupManager != null) {
            return groupManager.getWorldsHolder().getWorldPermissions(player).has(player, command);
        }
        else if (permissionsPlugin != null) {
            return (Permissions.Security.permission(player, command));
        }
        else if (permissionsExPlugin != null) {
            return (PermissionsEx.getPermissionManager().has(player, command));
        }
        else if(bPermissions != null){
            return bPermissions.has(player, command);
        }
        else if (player.hasPermission(command)) {
            return true;
        }
        else if (datawriter.isError() && player.isOp()) {
            return true;
        }
        else {
            return false;
        }
    }

    // permissions plugin enabled test
    private void getPermissionsPlugin() {
        if (server.getPluginManager().getPlugin("GroupManager") != null) {
            Plugin p = server.getPluginManager().getPlugin("GroupManager");
            if (!datawriter.isPermissionsSet()) {
                LOGGER.info("GroupManager detected, " + pluginName + " permissions enabled...");
                datawriter.setPermissionsSet(true);
            }
            groupManager = (GroupManager) p;
        }
        else if (server.getPluginManager().getPlugin("Permissions") != null) {
            Plugin p = server.getPluginManager().getPlugin("Permissions");
            if (!datawriter.isPermissionsSet()) {
                LOGGER.info("Permissions detected, " + pluginName + " permissions enabled...");
                datawriter.setPermissionsSet(true);
            }
            permissionsPlugin = (Permissions) p;
        }
        else if (server.getPluginManager().getPlugin("PermissionsEx") != null) {
            Plugin p = server.getPluginManager().getPlugin("PermissionsEx");
            if (!datawriter.isPermissionsSet()) {
                LOGGER.info("PermissionsEx detected, " + pluginName + " permissions enabled...");
                datawriter.setPermissionsSet(true);
            }
            permissionsExPlugin = (PermissionsEx) p;
        }
        else if (server.getPluginManager().getPlugin("bPermissions") != null) {
            Plugin p = server.getPluginManager().getPlugin("bPermissions");
            if (!datawriter.isPermissionsSet()) {
                LOGGER.info("bPermissions detected, " + pluginName + " permissions enabled...");
                datawriter.setPermissionsSet(true);
            }
            bPermissions = (de.bananaco.bpermissions.imp.Permissions) p;
        }
        else if (server.getPluginManager().getPlugin("PermissionsBukkit") != null) {
            if (!datawriter.isPermissionsSet()) {
                LOGGER.info("Bukkit permissions detected, " + pluginName + " permissions enabled...");
                datawriter.setPermissionsSet(true);
            }
        }
        else {
            if (!(datawriter.isError())) {
                LOGGER.info("Permissions not detected, " + pluginName + " in OPs mode...");
                datawriter.setError(true);
            }
        }
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] split) {
        Player player = null;
        if ((sender instanceof Player)) {
            player = (Player) sender;
            // inGame is the command handler for players sending commands from within the game
            return commandhandler.inGame(cmd, commandLabel, split, player);
        }
        else {
            // inConsole is the command handler for users not in game. IE Console
            if (datawriter.isEnableConsoleCommands())
                return commandhandler.inConsole(sender, cmd, split);
            else
                sender.sendMessage("Console commands are disabled. Enable them in the config file");
            return true;
        }
    }
}

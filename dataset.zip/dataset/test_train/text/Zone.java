package plugin.arcwolf.blockdoor.Zones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;

import plugin.arcwolf.blockdoor.Link;

public abstract class Zone implements Cloneable {

    public String zone_Type = "";
    public String zone_name = "";
    public String zone_creator = "";
    public String uzone_trigger = "";
    public int occupants;

    public int zone_start_x;
    public int zone_start_y;
    public int zone_start_z;
    public int zone_end_x;
    public int zone_end_y;
    public int zone_end_z;
    public boolean coordsSet;
    public final Map<Chunk, Chunk> zoneChunk = new HashMap<Chunk, Chunk>();
    private boolean initialized = false;

    public World world;

    public final List<Link> links = new ArrayList<Link>();
    public String zone_world = "";

    protected Zone(String in_Type, String in_name, String in_creator, String in_world) {
        zone_Type = in_Type;
        zone_name = in_name;
        zone_creator = in_creator;
        zone_world = in_world;
        coordsSet = false;
    }

    protected Zone(String in_Type, String in_name, String in_creator, String in_trigger, String in_world) {
        zone_Type = in_Type;
        zone_name = in_name;
        zone_creator = in_creator;
        zone_world = in_world;
        uzone_trigger = in_trigger;
        coordsSet = false;
    }
    
    protected Zone(Zone otherZone){
        this.zone_Type = otherZone.zone_Type;
        this.zone_name = otherZone.zone_name;
        this.zone_creator = otherZone.zone_creator;
        this.uzone_trigger = otherZone.uzone_trigger;
        this.occupants = otherZone.occupants;
        this.zone_start_x = otherZone.zone_start_x;
        this.zone_start_y = otherZone.zone_start_y;
        this.zone_start_z = otherZone.zone_start_z;
        this.zone_end_x = otherZone.zone_end_x;
        this.zone_end_y = otherZone.zone_end_y;
        this.zone_end_z = otherZone.zone_end_z;
        this.links.addAll(otherZone.links);
        this.zone_world = otherZone.zone_world;
        this.world = otherZone.world;
        this.coordsSet = otherZone.coordsSet;
    }

    protected Zone(String in_string) {
        String[] split = in_string.split(":");
        zone_Type = split[0];
        if (split.length == 12) {

            zone_creator = split[1];
            zone_name = split[2];

            zone_start_x = Integer.parseInt(split[3]);
            zone_start_y = Integer.parseInt(split[4]);
            zone_start_z = Integer.parseInt(split[5]);

            zone_end_x = Integer.parseInt(split[6]);
            zone_end_y = Integer.parseInt(split[7]);
            zone_end_z = Integer.parseInt(split[8]);
            coordsSet = Boolean.parseBoolean(split[9]);
            occupants = Integer.parseInt(split[10]);

            zone_world = split[11];
        }
        else if (split.length == 13) {
            if (!split[0].equals("UZONE")) {
                zone_creator = split[1];
                zone_name = split[2];

                zone_start_x = Integer.parseInt(split[3]);
                zone_start_y = Integer.parseInt(split[4]);
                zone_start_z = Integer.parseInt(split[5]);

                zone_end_x = Integer.parseInt(split[6]);
                zone_end_y = Integer.parseInt(split[7]);
                zone_end_z = Integer.parseInt(split[8]);
                coordsSet = Boolean.parseBoolean(split[9]);
                occupants = Integer.parseInt(split[10]);

                zone_world = split[11];

                String[] linksplit = split[12].split("\\|");
                Link l;
                for(int i = 0; i < linksplit.length; i++) {
                    l = new Link(linksplit[i]);
                    if (l.link_creator != "FAILED")
                        links.add(l);
                }
            }
            else {
                zone_creator = split[1];
                zone_name = split[2];

                uzone_trigger = split[3];

                zone_start_x = Integer.parseInt(split[4]);
                zone_start_y = Integer.parseInt(split[5]);
                zone_start_z = Integer.parseInt(split[6]);

                zone_end_x = Integer.parseInt(split[7]);
                zone_end_y = Integer.parseInt(split[8]);
                zone_end_z = Integer.parseInt(split[9]);
                coordsSet = Boolean.parseBoolean(split[10]);
                occupants = Integer.parseInt(split[11]);

                zone_world = split[12];
            }

        }
        else if (split.length == 14) {

            zone_creator = split[1];
            zone_name = split[2];

            uzone_trigger = split[3];

            zone_start_x = Integer.parseInt(split[4]);
            zone_start_y = Integer.parseInt(split[5]);
            zone_start_z = Integer.parseInt(split[6]);

            zone_end_x = Integer.parseInt(split[7]);
            zone_end_y = Integer.parseInt(split[8]);
            zone_end_z = Integer.parseInt(split[9]);
            coordsSet = Boolean.parseBoolean(split[10]);
            occupants = Integer.parseInt(split[11]);

            zone_world = split[12];

            String[] linksplit = split[13].split("\\|");
            Link l;
            for(int i = 0; i < linksplit.length; i++) {
                l = new Link(linksplit[i]);
                if (l.link_creator != "FAILED")
                    links.add(l);
            }
        }
        else {
            zone_creator = "FAILED";
            coordsSet = false;
        }
    }

    public final void processLinks() {
        for(Link l : links) {
            if (l.doorType.equalsIgnoreCase("ONESTATE"))
                l.process(world);
            else if (l.doorType.equalsIgnoreCase("HYBRIDSTATE"))
                l.processHybrid(world);
            else
                l.processTwoState(world);
        }
    }
    
    public final boolean isInZone(Location l) {
        int x = l.getBlockX();
        int y = l.getBlockY();
        int z = l.getBlockZ();
        return isInZone(x, y, z);
    }

    public final boolean isInZone(int x, int y, int z) {
        return (zone_start_x <= x && x <= zone_end_x &&
                zone_start_y <= y && y <= zone_end_y &&
                zone_start_z <= z && z <= zone_end_z);
    }

    @Override
    public final Zone clone() throws CloneNotSupportedException {
        Zone newZone = (Zone) super.clone();
        // May need to further override default clone.
        // Seems ok but... 
        return newZone;
    }

    @Override
    public final int hashCode() {
        return super.hashCode();
    }

    @Override
    public final boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Zone other = (Zone) obj;
        if (zone_Type == null) {
            if (other.zone_Type != null) return false;
        }
        else if (!zone_Type.equals(other.zone_Type)) return false;
        if (uzone_trigger == null) {
            if (other.uzone_trigger != null) return false;
        }
        else if (!uzone_trigger.equals(other.uzone_trigger)) return false;
        if (zone_creator == null) {
            if (other.zone_creator != null) return false;
        }
        else if (!zone_creator.equals(other.zone_creator)) return false;
        if (zone_end_x != other.zone_end_x) return false;
        if (zone_end_y != other.zone_end_y) return false;
        if (zone_end_z != other.zone_end_z) return false;
        if (zone_name == null) {
            if (other.zone_name != null) return false;
        }
        else if (!zone_name.equals(other.zone_name)) return false;
        if (zone_start_x != other.zone_start_x) return false;
        if (zone_start_y != other.zone_start_y) return false;
        if (zone_start_z != other.zone_start_z) return false;
        if (zone_world == null) {
            if (other.zone_world != null) return false;
        }
        else if (!zone_world.equals(other.zone_world)) return false;
        return true;
    }

    public final boolean isInitialized() {
        return initialized;
    }

    public final void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }
}

package plugin.arcwolf.blockdoor.Zones;

/*
 * Handles searching of zones, adding new zones to correct lists, and creating zones.
 */

import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import plugin.arcwolf.blockdoor.BlockDoor;
import plugin.arcwolf.blockdoor.Utils.BlockDoorSettings;
import plugin.arcwolf.blockdoor.Utils.DataWriter;

@SuppressWarnings("unchecked")
public class ZoneHelper {

    public BlockDoor plugin;
    public DataWriter dataWriter;

    private enum zoneType {
        ZONE, MYZONE, UZONE, AZONE, MZONE, EZONE, PZONE
    }

    public ZoneHelper() {
        plugin = BlockDoor.plugin;
        dataWriter = plugin.datawriter;
    }

    public Zone findZone(String in_type, String in_name, String in_creator, String in_world) {
        for(Zone z : dataWriter.allZones)
            if (z.zone_Type.equals(in_type) && z.zone_name.equals(in_name) && z.zone_creator.equals(in_creator) && z.zone_world.equals(in_world)) {
                z.world = plugin.getWorld(in_world);
                return z;
            }
        return null;
    }

    public Zone findZone(String in_type, String in_name, String in_creator, String in_trigger, String in_world) {
        for(Zone z : dataWriter.allZones)
            if (z.zone_Type.equals(in_type) && z.zone_name.equals(in_name) && z.zone_creator.equals(in_creator) && z.uzone_trigger.equals(in_trigger) && z.zone_world.equals(in_world)) {
                z.world = plugin.getWorld(in_world);
                return z;
            }
        return null;
    }

    public Zone addZone(String in_name, String in_creator, String in_world, Player player) {
        BlockDoorSettings settings = BlockDoorSettings.getSettings(player);
        String zoneType = friendlyCommandToType(settings);
        for(Zone z : dataWriter.allZones)
            if (z.zone_Type.equals(zoneType) && z.zone_name.equals(in_name) && z.zone_creator.equals(in_creator) && z.zone_world.equals(in_world)) {
                z.world = plugin.getWorld(in_world);
                return z;
            }

        Zone newZone = null;
        if (settings.friendlyCommand.equals("dazone"))
            newZone = new AggressiveMobZone("AZONE", in_name, in_creator, in_world);
        else if (settings.friendlyCommand.equals("dezone"))
            newZone = new AllLivingEntitiesZone("EZONE", in_name, in_creator, in_world);
        else if (settings.friendlyCommand.equals("dmzone"))
            newZone = new AllMobZone("MZONE", in_name, in_creator, in_world);
        else if (settings.friendlyCommand.equals("dmyzone"))
            newZone = new MyZone("MYZONE", in_name, in_creator, in_world);
        else if (settings.friendlyCommand.equals("dpzone"))
            newZone = new PassiveMobZone("PZONE", in_name, in_creator, in_world);
        else
            newZone = new PlayerZone("ZONE", in_name, in_creator, in_world);
        dataWriter.allZones.add(newZone);
        settings.notFound = 1;
        return newZone;
    }

    public Zone addZone(String in_name, String in_creator, String in_trigger, String in_world, Player player) {
        BlockDoorSettings settings = BlockDoorSettings.getSettings(player);
        for(Zone z : dataWriter.allZones)
            if (z.zone_Type.equals("UZONE") && z.zone_name.equals(in_name) && z.zone_creator.equals(in_creator) && z.uzone_trigger.equals(in_trigger) && z.zone_world.equals(in_world)) {
                z.world = plugin.getWorld(in_world);
                return z;
            }

        Zone newZone = new SelectedEntityZone("UZONE", in_name, in_creator, in_trigger, in_world);
        dataWriter.allZones.add(newZone);
        settings.notFound = 1;
        return newZone;
    }

    public int findZone(Zone zone) {
        int index = -1;
        for(int i = 0; i < dataWriter.allZones.size(); i++)
            if (zone.equals(dataWriter.allZones.get(i))) {
                zone.world = plugin.getWorld(zone.zone_world);
                index = i;
            }
        return index;
    }

    public Zone findCoordinates(List<?> zoneList, int x, int y, int z, String in_world) {
        List<Zone> zones = (List<Zone>) zoneList;
        for(Zone foundZone : zones) {
            if (foundZone.zone_start_x <= x && x <= foundZone.zone_end_x
                    && foundZone.zone_start_y <= y && y <= foundZone.zone_end_y
                    && foundZone.zone_start_z <= z && z <= foundZone.zone_end_z) { return foundZone; }
        }
        return null;
    }

    public int findLink(Zone z, String in_name, String in_creator, String in_state) {
        int index = -1;
        for(int j = 0; j < z.links.size(); j++)
            if (z.links.get(j).link_name.equals(in_name) && z.links.get(j).link_creator.equals(in_creator) && z.links.get(j).doorType.equals(in_state))
                return j;
        return index;
    }

    /**
     * Creates a zone in the specified zone list.
     * 
     * @param zoneList
     * @param settings
     * @param player
     * @param blockClicked
     * @param isUzone
     */
    public void createZone(BlockDoorSettings settings, Player player, Block blockClicked, boolean isUzone) {
        Zone foundZone;
        if (isUzone)
            foundZone = addZone(settings.name, player.getName(), settings.trigger, player.getWorld().getName(), player);
        else
            foundZone = addZone(settings.name, player.getName(), player.getWorld().getName(), player);
        int blockX = (int) blockClicked.getLocation().getX();
        int blockY = (int) blockClicked.getLocation().getY();
        int blockZ = (int) blockClicked.getLocation().getZ();
        try {
            settings.zone = foundZone.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        if (settings.select == 1) {
            player.sendMessage("Setting zone start: '" + ChatColor.GREEN + settings.name + ChatColor.WHITE + "'");
            foundZone.zone_start_x = blockX;
            foundZone.zone_start_y = blockY;
            foundZone.zone_start_z = blockZ;
            settings.select = 2;
        }
        else if (settings.select == 2) {
            player.sendMessage("Setting zone end: '" + ChatColor.GREEN + settings.name + ChatColor.WHITE + "'");
            if (foundZone.zone_start_x > blockX) {
                foundZone.zone_end_x = foundZone.zone_start_x;
                foundZone.zone_start_x = blockX;
            }
            else {
                foundZone.zone_end_x = blockX;
            }
            if (foundZone.zone_start_y > blockY) {
                foundZone.zone_end_y = foundZone.zone_start_y;
                foundZone.zone_start_y = blockY;
            }
            else {
                foundZone.zone_end_y = blockY;
            }
            if (foundZone.zone_start_z > blockZ) {
                foundZone.zone_end_z = foundZone.zone_start_z;
                foundZone.zone_start_z = blockZ;
            }
            else {
                foundZone.zone_end_z = blockZ;
            }
            foundZone.zone_world = player.getWorld().getName();
            int xDist = Math.abs(foundZone.zone_end_x - foundZone.zone_start_x);
            int yDist = Math.abs(foundZone.zone_end_y - foundZone.zone_start_y);
            int zDist = Math.abs(foundZone.zone_end_z - foundZone.zone_start_z);
            if (dataWriter.getMax_ZoneSize() != -1 && ((xDist + 1 > dataWriter.getMax_ZoneSize()) || (yDist + 1 > dataWriter.getMax_ZoneSize()) || (zDist + 1 > dataWriter.getMax_ZoneSize()))) {
                player.sendMessage(ChatColor.RED + "ZONE DIMENSIONS REJECTED for: '" + ChatColor.WHITE + settings.name + ChatColor.RED + "'");
                if (foundZone.coordsSet) {
                    try {
                        foundZone = settings.zone.clone();
                    } catch (CloneNotSupportedException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    dataWriter.allZones.remove(foundZone);
                }
            }
            else {
                boolean found = false;
                if (!dataWriter.isOverlapZones()) {
                    search:
                    for(int x = foundZone.zone_start_x; x <= foundZone.zone_end_x; x++)
                        for(int z = foundZone.zone_start_z; z <= foundZone.zone_end_z; z++)
                            for(int y = foundZone.zone_start_y; y <= foundZone.zone_end_y; y++) {
                                for(Zone az : dataWriter.allZones) {
                                    if (az.zone_world.equals(foundZone.zone_world))
                                        if (az.isInZone(x, y, z) && !az.equals(foundZone)) {
                                            showOverlapMsg(az, player);
                                            found = true;
                                            break search;
                                        }
                                }
                            }
                    if (found) {
                        player.sendMessage(ChatColor.RED + getZoneType(foundZone).name() + " '" + ChatColor.WHITE + settings.name + ChatColor.RED + "' REJECTED");
                        if (foundZone.coordsSet) {
                            try {
                                foundZone = settings.zone.clone();
                            } catch (CloneNotSupportedException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            dataWriter.allZones.remove(foundZone);
                        }
                    }
                    else {
                        foundZone.occupants = 0;
                        foundZone.coordsSet = true;
                        updateChunkMap(foundZone);
                        dataWriter.saveDatabase();
                    }
                }
                else {
                    foundZone.occupants = 0;
                    foundZone.coordsSet = true;
                    updateChunkMap(foundZone);
                    dataWriter.saveDatabase();
                }
            }
            settings.select = 0;
            settings.command = "";
            settings.notFound = 0;
        }
    }

    private void updateChunkMap(Zone foundZone) {
        foundZone.setInitialized(false);
    }

    private void showOverlapMsg(Zone foundZone, Player player) {
        player.sendMessage("Overlap of " + getFriendlyZoneName(foundZone) + " [" + ChatColor.GREEN + foundZone.zone_name + ChatColor.WHITE + "] Created by [" +
                ChatColor.GREEN + foundZone.zone_creator + ChatColor.WHITE + "]");
        player.sendMessage("Starting at [X= " + ChatColor.AQUA + foundZone.zone_start_x + ChatColor.WHITE + " Y= " +
                ChatColor.AQUA + foundZone.zone_start_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                foundZone.zone_start_z + ChatColor.WHITE + "]");
        player.sendMessage("Ending at [X= " + ChatColor.AQUA + foundZone.zone_end_x + ChatColor.WHITE + " Y= " +
                ChatColor.AQUA + foundZone.zone_end_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                foundZone.zone_end_z + ChatColor.WHITE + "] in world [" + ChatColor.AQUA +
                foundZone.zone_world + ChatColor.WHITE + "]");
    }

    private zoneType getZoneType(Zone foundZone) {
        if (foundZone.zone_Type.equals("AZONE"))
            return zoneType.AZONE;
        if (foundZone.zone_Type.equals("EZONE"))
            return zoneType.EZONE;
        if (foundZone.zone_Type.equals("MZONE"))
            return zoneType.MZONE;
        if (foundZone.zone_Type.equals("MYZONE"))
            return zoneType.MYZONE;
        if (foundZone.zone_Type.equals("PZONE"))
            return zoneType.PZONE;
        if (foundZone.zone_Type.equals("ZONE"))
            return zoneType.ZONE;
        if (foundZone.zone_Type.equals("UZONE"))
            return zoneType.UZONE;
        return null;
    }

    public String getFriendlyZoneName(Zone foundZone) {
        if (foundZone.zone_Type.equals("AZONE"))
            return "Aggressive Mob Zone";
        if (foundZone.zone_Type.equals("EZONE"))
            return "Living Entity Zone";
        if (foundZone.zone_Type.equals("MZONE"))
            return "Mob Zone";
        if (foundZone.zone_Type.equals("MYZONE"))
            return "My Zone";
        if (foundZone.zone_Type.equals("PZONE"))
            return "Passive Mob Zone";
        if (foundZone.zone_Type.equals("ZONE"))
            return "Player Zone";
        if (foundZone.zone_Type.equals("UZONE"))
            return "Selected Entity Zone";
        return "";
    }

    public int getNumberOfZoneTypes() {
        zoneType[] z = zoneType.values();
        return z.length;
    }

    private String friendlyCommandToType(BlockDoorSettings settings) {
        if (settings.friendlyCommand.equals("dazone"))
            return "AZONE";
        else if (settings.friendlyCommand.equals("dezone"))
            return "EZONE";
        else if (settings.friendlyCommand.equals("dmzone"))
            return "MZONE";
        else if (settings.friendlyCommand.equals("dmyzone"))
            return "MYZONE";
        else if (settings.friendlyCommand.equals("dpzone"))
            return "PZONE";
        else
            return "ZONE";
    }
}
package plugin.arcwolf.blockdoor.Utils;

/*
 * Contains all the little special case checks for objects that like to POP into items if the server thinks they are
 * placed wrongly
 */

public class SpecialCaseCheck {

    public static boolean grassOrDirt(int blockID) {
        return blockID == 2 || blockID == 3;
    }

    public static boolean isWater(int blockID) {
        return blockID == 8 || blockID == 9;
    }

    public static boolean validSolids(int blockID) {
        return blockID == 1 || blockID == 2 || blockID == 3 || blockID == 4 || blockID == 5 || blockID == 7 ||
                blockID == 12 || blockID == 13 || blockID == 14 || blockID == 15 || blockID == 16 || blockID == 17 ||
                blockID == 18 || blockID == 19 || blockID == 21 || blockID == 22 || blockID == 24 || blockID == 35 ||
                blockID == 41 || blockID == 42 || blockID == 43 || blockID == 45 || blockID == 47 || blockID == 48 ||
                blockID == 49 || blockID == 56 || blockID == 57 || blockID == 73 || blockID == 74 || blockID == 80 ||
                blockID == 82 || blockID == 86 || blockID == 87 || blockID == 88 || blockID == 89 || blockID == 91 ||
                blockID == 98 || blockID == 110 || blockID == 112 || blockID == 121 || blockID == 125 || blockID == 129 ||
                blockID == 133;
    }

    public static boolean mushroomCheck(int blockID) {
        return blockID == 1 || blockID == 2 || blockID == 3 || blockID == 4 || blockID == 5 || blockID == 7 ||
                blockID == 12 || blockID == 13 || blockID == 14 || blockID == 15 || blockID == 16 || blockID == 17 ||
                blockID == 18 || blockID == 19 || blockID == 21 || blockID == 22 || blockID == 24 || blockID == 35 ||
                blockID == 41 || blockID == 42 || blockID == 45 || blockID == 47 || blockID == 48 || blockID == 49 ||
                blockID == 56 || blockID == 57 || blockID == 73 || blockID == 74 || blockID == 80 || blockID == 82 ||
                blockID == 86 || blockID == 87 || blockID == 88 || blockID == 91;
    }

    public static boolean netherWartCheck(int blockID) {
        return blockID == 88;
    }

    public static boolean cactusCheck(int blockID) {
        return blockID == 12;
    }

    public static boolean cropCheck(int blockID) {
        return blockID == 60;
    }

    public static boolean lilyPadCheck(int blockID) {
        return blockID == 8 || blockID == 9;
    }

    public static boolean isSpecialBlock(int blockID) {
        return blockID == 27 || blockID == 28 || blockID == 31 || blockID == 32 || blockID == 37 ||
                blockID == 38 || blockID == 39 || blockID == 40 || blockID == 50 || blockID == 55 ||
                blockID == 59 || blockID == 64 || blockID == 65 || blockID == 66 || blockID == 69 ||
                blockID == 70 || blockID == 71 || blockID == 72 || blockID == 75 || blockID == 76 ||
                blockID == 77 || blockID == 81 || blockID == 83 || blockID == 93 || blockID == 94 ||
                blockID == 96 || blockID == 111 || blockID == 115 || blockID == 131 || blockID == 132;
    }

    public static boolean isRejectedBlock(int blockID) {
        return blockID == 8 || blockID == 9 || blockID == 10 || blockID == 11 ||
                blockID == 12 || blockID == 13 || blockID == 26 || blockID == 29 ||
                blockID == 33 || blockID == 34 || blockID == 46 || blockID == 52 ||
                blockID == 63 || blockID == 68 || blockID == 119 || blockID == 122;
    }

    public static boolean isWatchedBlock(int blockID) {
        return blockID == 6 || blockID == 27 || blockID == 28 || blockID == 31 || blockID == 32 || blockID == 37 ||
                blockID == 38 || blockID == 39 || blockID == 40 || blockID == 50 || blockID == 55 || blockID == 59 ||
                blockID == 64 || blockID == 65 || blockID == 66 || blockID == 69 || blockID == 71 || blockID == 75 ||
                blockID == 76 || blockID == 81 || blockID == 83 || blockID == 93 || blockID == 94 || blockID == 96 ||
                blockID == 111 || blockID == 115 || blockID == 131 || blockID == 132;
    }
}
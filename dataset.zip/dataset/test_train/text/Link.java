package plugin.arcwolf.blockdoor;

import java.util.logging.Level;

import org.bukkit.World;

import plugin.arcwolf.blockdoor.BlockDoor.Types;
import plugin.arcwolf.blockdoor.Utils.DataWriter;

public class Link {
    
    public String link_name;
    public String link_creator;
    public Types linkType;
    public String doorType;

    public Link(String in_target, String in_creator, String in_type, String in_doorType) {
        link_name = in_target;
        link_creator = in_creator;

        if (in_type.equalsIgnoreCase("TOGGLE") || in_type.equalsIgnoreCase("T"))
            linkType = Types.TOGGLE;
        else if (in_type.equalsIgnoreCase("ON") || in_type.equalsIgnoreCase("OPEN"))
            linkType = Types.OPEN;
        else if (in_type.equalsIgnoreCase("OFF") || in_type.equalsIgnoreCase("CLOSE"))
            linkType = Types.CLOSE;
        else
            linkType = Types.DISABLED;

        if (in_doorType.equalsIgnoreCase("ONESTATE"))
            doorType = "ONESTATE";
        else if (in_doorType.equalsIgnoreCase("TWOSTATE"))
            doorType = "TWOSTATE";
        else if (in_doorType.equalsIgnoreCase("HYBRIDSTATE"))
            doorType = "HYBRIDSTATE";
        else
            doorType = "ONESTATE";
    }

    public Link(String in_string) {
        String[] split = in_string.split("\\s");
        if (split.length == 3) {
            link_name = split[0];
            link_creator = split[1];

            if (split[2].equalsIgnoreCase("TOGGLE") || split[2].equalsIgnoreCase("T"))
                linkType = Types.TOGGLE;
            else if (split[2].equalsIgnoreCase("ON") || split[2].equalsIgnoreCase("OPEN"))
                linkType = Types.OPEN;
            else if (split[2].equalsIgnoreCase("OFF") || split[2].equalsIgnoreCase("CLOSE"))
                linkType = Types.CLOSE;
            else
                linkType = Types.DISABLED;

            doorType = "ONESTATE";
        }
        else if (split.length == 4) {
            link_name = split[0];
            link_creator = split[1];

            if (split[2].equalsIgnoreCase("TOGGLE") || split[2].equalsIgnoreCase("T"))
                linkType = Types.TOGGLE;
            else if (split[2].equalsIgnoreCase("ON") || split[2].equalsIgnoreCase("OPEN"))
                linkType = Types.OPEN;
            else if (split[2].equalsIgnoreCase("OFF") || split[2].equalsIgnoreCase("CLOSE"))
                linkType = Types.CLOSE;
            else
                linkType = Types.DISABLED;

            doorType = split[3];
        }
        else
            link_creator = "FAILED";
    }

    public void processTwoState(World world) {
        BlockDoor plugin = BlockDoor.plugin;
        DataWriter dataWriter = plugin.datawriter;
        int id = plugin.twostatedoorhelper.findDoor(link_name, link_creator, world.getName());
        if (id != -1) {
            plugin.datawriter.twostate.get(id).world = world;
            switch (linkType) {
                case TOGGLE:
                    dataWriter.twostate.get(id).toggle();
                    break;
                case OPEN:
                    dataWriter.twostate.get(id).open();
                    break;
                case CLOSE:
                    dataWriter.twostate.get(id).close();
                    break;
                default:
                    BlockDoor.LOGGER.log(Level.INFO, "ERROR PARSING LINK!");
                    break;
            }
        }
        else {
            BlockDoor.LOGGER.info("BlockDoor: The door ' " + link_name + " ' created by ' " + link_creator + " ' in world ' " + world.getName() + " ' attempted to toggle but has no record that it exists.");
        }
    }

    public void process(World world) {
        BlockDoor plugin = BlockDoor.plugin;
        DataWriter dataWriter = plugin.datawriter;
        int id = plugin.singlestatedoorhelper.findDoor(link_name, link_creator, world.getName());
        if (id != -1) {
            plugin.datawriter.doors.get(id).world = world;
            switch (linkType) {
                case TOGGLE:
                    dataWriter.doors.get(id).toggle();
                    break;
                case OPEN:
                    dataWriter.doors.get(id).open();
                    break;
                case CLOSE:
                    dataWriter.doors.get(id).close();
                    break;
                default:
                    BlockDoor.LOGGER.log(Level.INFO, "ERROR PARSING LINK!");
                    break;
            }
        }
        else {
            BlockDoor.LOGGER.info("BlockDoor: The door ' " + link_name + " ' created by ' " + link_creator + " ' in world ' " + world.getName() + " ' attempted to toggle but has no record that it exists.");
        }
    }

    public void processHybrid(World world) {
        BlockDoor plugin = BlockDoor.plugin;
        DataWriter dataWriter = plugin.datawriter;
        int id = plugin.hdoorhelper.findDoor(link_name, link_creator, world.getName());
        //System.out.println(link_name + " " + link_creator + " " + world.getName() + " " + id);
        if (id != -1) {
            plugin.datawriter.hdoor.get(id).world = world;            
            switch (linkType) {
                case TOGGLE:
                    dataWriter.hdoor.get(id).toggle();
                    break;
                case OPEN:
                    dataWriter.hdoor.get(id).open();
                    break;
                case CLOSE:
                    dataWriter.hdoor.get(id).close();
                    break;
                default:
                    BlockDoor.LOGGER.log(Level.INFO, "ERROR PARSING LINK!");
                    break;
            }
        }
        else {
            BlockDoor.LOGGER.info("BlockDoor: The Hybrid door ' " + link_name + " ' created by ' " + link_creator + " ' in world ' " + world.getName() + " ' attempted to toggle but has no record that it exists.");
        }
    }
}
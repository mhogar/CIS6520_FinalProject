package plugin.arcwolf.blockdoor.Utils;

import java.util.Hashtable;

import org.bukkit.entity.Player;

import plugin.arcwolf.blockdoor.Zones.Zone;

public class BlockDoorSettings {
    @SuppressWarnings("rawtypes")
    static Hashtable playerSettings = new Hashtable();
    //command used
    public String command = "";
    public String friendlyCommand = "";
    //users name
    public String name = "";
    //trigger name for uzones
    public String trigger = "";

    //control variable for the different functions
    //ie. Door start / end selection
    public int select = 0;

    //find control for commands
    public int notFound = 0;

    //overlap control for doors
    public int old_door_start_x = 0;
    public int old_door_start_y = 0;
    public int old_door_start_z = 0;
    public int old_door_end_x = 0;
    public int old_door_end_y = 0;
    public int old_door_end_z = 0;
    public String old_door_world = "";

    //work around for bug in onBlockPlace getData()
    public boolean placed = false;
    public int twoStateDoorIndex = -1;
    public int stateOneIndex = -1;
    public int stateTwoIndex = -1;
    
    //overlap control & prevention for zone commands
    public Zone zone = null;
    
    //teleport prevention
    public int index = -1;

    //used to cancel the block break event on redstone if a user left clicks to create a redstone trigger.
    public int leftClick = 0;

    //Returns a BlockDoorSettings for the player, making a new one if needed
    @SuppressWarnings("unchecked")
    public static BlockDoorSettings getSettings(Player player) {
        BlockDoorSettings settings = (BlockDoorSettings) playerSettings.get(player.getName());
        if (settings == null) {
            playerSettings.put(player.getName(), new BlockDoorSettings());
            settings = (BlockDoorSettings) playerSettings.get(player.getName());
        }
        return (settings);
    }
}
package plugin.arcwolf.blockdoor.Utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;

import plugin.arcwolf.blockdoor.AllZonesList;
import plugin.arcwolf.blockdoor.BlockDoor;
import plugin.arcwolf.blockdoor.Link;
import plugin.arcwolf.blockdoor.Doors.Door;
import plugin.arcwolf.blockdoor.Doors.HDoor;
import plugin.arcwolf.blockdoor.Doors.SingleStateDoor;
import plugin.arcwolf.blockdoor.Doors.TwoStateDoor;
import plugin.arcwolf.blockdoor.Triggers.BlockTrigger;
import plugin.arcwolf.blockdoor.Triggers.MyTrigger;
import plugin.arcwolf.blockdoor.Triggers.RedTrig;
import plugin.arcwolf.blockdoor.Triggers.Trigger;
import plugin.arcwolf.blockdoor.Zones.AggressiveMobZone;
import plugin.arcwolf.blockdoor.Zones.AllLivingEntitiesZone;
import plugin.arcwolf.blockdoor.Zones.AllMobZone;
import plugin.arcwolf.blockdoor.Zones.MyZone;
import plugin.arcwolf.blockdoor.Zones.PassiveMobZone;
import plugin.arcwolf.blockdoor.Zones.PlayerZone;
import plugin.arcwolf.blockdoor.Zones.SelectedEntityZone;
import plugin.arcwolf.blockdoor.Zones.Zone;

public class DataWriter {

    private BlockDoor plugin;

    //Door arrays
    public final List<SingleStateDoor> doors = new ArrayList<SingleStateDoor>();
    public final List<TwoStateDoor> twostate = new ArrayList<TwoStateDoor>();
    public final List<HDoor> hdoor = new ArrayList<HDoor>();

    //triggers array
    public final List<Trigger> allTriggers = new ArrayList<Trigger>();
    
    //zones array
    public final List<Zone> allZones = new ArrayList<Zone>();

    //Item database array
    public final List<ItemCodes> itemcodes = new ArrayList<ItemCodes>();

    //zone occupancy tracker array
    public final List<AllZonesList> zoneOccupancyList = new ArrayList<AllZonesList>();

    public final Map<Class<?>, List<String>> mobs = new HashMap<Class<?>, List<String>>();
    public final Map<Door, Boolean> doorPhysics = new HashMap<Door, Boolean>();

    //config variables
    private int max_DoorSize = 10;
    private int max_TwoStateSize = 20;
    private int max_hdoorSize = 50;
    private int max_ZoneSize = 20;

    private boolean overlapZones = false;
    private boolean overlapDoors = false;
    private boolean overlapTwoStateDoors = false;
    private boolean overlapHDoors = false;
    private boolean overlapTriggers = false;
    private boolean overlapRedstone = false;

    private boolean enableSpecialBlocks = false;
    private boolean enableConsoleCommands = false;

    //Item database error control variable
    private boolean itemDatabaseEr = false;

    //Uzone database error control variable
    private boolean uzoneDatabaseEr = false;

    //error control variable
    private boolean permissionsSet = false;
    private boolean error = false;

    //Admin plugin reload function
    private boolean reload = false;

    private String oldDoorsFile = "blockdoors.txt";
    private String doorsConfig = "config.txt";
    private String itemsDatabase = "items.txt";
    private String newDoorsFile = "blockdoor.dat";
    private String uzoneDB = "mobs.txt";
    private File directory;
    private File oldDoorTXTDatabase;
    private File newDoorBinDatabase;
    private File doorConfig;
    private File itemDatabase;
    private File uzoneDatabase;

    public DataWriter() {
        plugin = BlockDoor.plugin;
        directory = plugin.getDataFolder();
        oldDoorTXTDatabase = new File(directory, oldDoorsFile);
        newDoorBinDatabase = new File(directory, newDoorsFile);
        doorConfig = new File(directory, doorsConfig);
        itemDatabase = new File(directory, itemsDatabase);
        uzoneDatabase = new File(directory, uzoneDB);
    }

    public void initFile() {
        boolean initialized = false;
        if (initialized)
            return;
        initialized = true;
        if (!directory.exists()) {
            BlockDoor.LOGGER.info("BlockDoor folder does not exist - creating it... ");
            boolean chk = directory.mkdir();
            if (chk)
                BlockDoor.LOGGER.info("Successfully created folder.");
            else
                BlockDoor.LOGGER.info("Unable to create folder!");
        }
        if (!newDoorBinDatabase.exists()) {
            ObjectOutputStream outputStream;
            try {
                BlockDoor.LOGGER.info("BlockDoor Data File does not exist - creating it... ");
                outputStream = new ObjectOutputStream(new FileOutputStream(newDoorBinDatabase));
                outputStream.writeObject("");
                outputStream.close();
                BlockDoor.LOGGER.info("Successfully created New Data File.");
            } catch (FileNotFoundException e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while creating " + newDoorBinDatabase.getAbsolutePath() + "\n", e);
            } catch (IOException e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while creating " + newDoorBinDatabase.getAbsolutePath() + "\n", e);
            }
        }
        if (!doorConfig.exists()) {
            FileWriter fwriter = null;
            BufferedWriter writer = null;
            try {
                BlockDoor.LOGGER.info("BlockDoor Config File does not exist - creating it... ");
                fwriter = new FileWriter(doorConfig);
                writer = new BufferedWriter(fwriter);
                writer.write("#Max size for X Y Z\r\n");
                writer.write("# -1 to override\r\n");
                writer.write("max_zone_size=20\r\n");
                writer.write("max_door_size=10\r\n");
                writer.write("max_twostate_size=20\r\n");
                writer.write("max_hdoor_size=50\r\n");
                writer.write("#\r\n");
                writer.write("#Advanced Users\r\n");
                writer.write("#\r\n");
                writer.write("allow_overlap_zones=false\r\n");
                writer.write("allow_overlap_doors=false\r\n");
                writer.write("allow_overlap_twostatedoors=false\r\n");
                writer.write("allow_overlap_hdoors=false\r\n");
                writer.write("allow_overlap_triggers=false\r\n");
                writer.write("allow_overlap_redstone=false\r\n");
                writer.write("allow_special_blocks=false\r\n");
                writer.write("allow_console_commands=false\r\n");
            } catch (Exception e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while creating " + doorsConfig, e);
            } finally {
                if (writer != null) {
                    try {
                        writer.flush();
                        writer.close();
                        BlockDoor.LOGGER.info("Successfully created New Config File.");
                    } catch (IOException e) {
                        BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor error " + e);
                    }
                }
                if (fwriter != null) {
                    try {
                        fwriter.close();
                    } catch (IOException e) {
                        BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor error " + e);
                    }
                }
            }
        }
        if (!itemDatabase.exists()) {
            FileWriter fwriter = null;
            BufferedWriter writer = null;
            try {
                BlockDoor.LOGGER.info("BlockDoor Item Database does not exist - creating it...");
                fwriter = new FileWriter(itemDatabase);
                writer = new BufferedWriter(fwriter);
                writer.write("###########################################################################\r\n");
                writer.write("# All items listed must be listed in the following format\r\n");
                writer.write("# No spaces or tabs\r\n");
                writer.write("#   Ex: 1,0=stone\r\n");
                writer.write("#   or\r\n");
                writer.write("#   Ex: 5,0=wood,woodplank\r\n");
                writer.write("#\r\n");
                writer.write("# All items listed must be listed in ascending numerical order\r\n");
                writer.write("#\r\n");
                writer.write("# Database faults will cause blockdoor to revert to its internal database\r\n");
                writer.write("###########################################################################\r\n");
                writer.write("0,0=air\r\n");
                writer.write("1,0=stone\r\n");
                writer.write("2,0=grass\r\n");
                writer.write("3,0=dirt\r\n");
                writer.write("4,0=cobblestone\r\n");
                writer.write("5,0=wood,woodplank,woodenplank,woodenplanks\r\n");
                writer.write("7,0=bedrock,adminium\r\n");
                writer.write("8,0=water,flowingwater\r\n");
                writer.write("9,0=stillwater,stationarywater\r\n");
                writer.write("10,0=lava,flowinglava\r\n");
                writer.write("11,0=stilllava,stationarylava\r\n");
                writer.write("12,0=sand\r\n");
                writer.write("13,0=gravel\r\n");
                writer.write("14,0=goldore\r\n");
                writer.write("15,0=ironore\r\n");
                writer.write("16,0=coalore\r\n");
                writer.write("17,0=log\r\n");
                writer.write("17,1=redwood,darklog,redwoodlog\r\n");
                writer.write("17,2=birch,birchlog\r\n");
                writer.write("18,0=leaves\r\n");
                writer.write("18,1=redwood\r\n");
                writer.write("18,2=birch\r\n");
                writer.write("19,0=sponge\r\n");
                writer.write("20,0=glass\r\n");
                writer.write("21,0=lapisore,lapislazuliore\r\n");
                writer.write("22,0=lapisblock,lapislazuliblock,lapis\r\n");
                writer.write("24,0=sandstone\r\n");
                writer.write("30,0=web,spiderweb,webbing\r\n");
                writer.write("35,0=wool,whitewool,whitecloth,cloth,wool,white\r\n");
                writer.write("35,1=orangewool,orangecloth,orange\r\n");
                writer.write("35,2=magentawool,magentacloth,magenta\r\n");
                writer.write("35,3=lightbluecloth,lightbluewool,lightblue\r\n");
                writer.write("35,4=yellowwool,yellowcloth,yellow\r\n");
                writer.write("35,5=lightgreenwool,lightgreencloth,limecloth,limewool,lightgreen,lime\r\n");
                writer.write("35,6=pinkwool,pinkcloth,pink\r\n");
                writer.write("35,7=greycloth,greywool,graywool,graycloth,grey,gray\r\n");
                writer.write("35,8=lightgreycloth,lightgreywool,lightgraywool,lightgraycloth,lightgrey,lightgray\r\n");
                writer.write("35,9=cyancloth,cyanwool,cyan\r\n");
                writer.write("35,10=purplecloth,purplewool,purple\r\n");
                writer.write("35,11=bluecloth,bluewool,blue\r\n");
                writer.write("35,12=brownwool,browncloth,brown\r\n");
                writer.write("35,13=darkgreenwool,darkgreencloth,darkgreen\r\n");
                writer.write("35,14=redcloth,redwool,red\r\n");
                writer.write("35,15=blackcloth,blackwool,black\r\n");
                writer.write("41,0=goldblock\r\n");
                writer.write("42,0=ironblock\r\n");
                writer.write("43,0=doublestoneslab,doublestep,doubleslab\r\n");
                writer.write("43,1=doublesandstoneslab,doublesandslab,sandstone,sandstoneslab,sandstonestep\r\n");
                writer.write("43,2=doublewoodenslab,doublewoodslab,wood,doublewoodstep,doublewoodenstep\r\n");
                writer.write("43,3=doublecobblestoneslab,doublecobbleslab,cobblestone,cobblestoneslab,cobblestonestep\r\n");
                writer.write("44,4=doublebrickslab\r\n");
                writer.write("44,5=doublestonebrickslab\r\n");
                writer.write("44,0=stoneslab,step,slab,stoneslab,stonestep\r\n");
                writer.write("44,1=sandstoneslab,sandslab,sandstone,sandstonestep\r\n");
                writer.write("44,2=woodenslab,woodslab,wood,woodenstep\r\n");
                writer.write("44,3=cobblestoneslab,cobbleslab,cobblestone,cobblestonestep\r\n");
                writer.write("44,4=brickslab\r\n");
                writer.write("44,5=stonebrickslab\r\n");
                writer.write("45,0=brick\r\n");
                writer.write("47,0=bookcase,bookshelf\r\n");
                writer.write("48,0=mossycobblestone,mossycobble,mossstone,mossystone\r\n");
                writer.write("49,0=obsidian\r\n");
                writer.write("51,0=fire\r\n");
                writer.write("56,0=diamondore\r\n");
                writer.write("57,0=diamondblock\r\n");
                writer.write("73,0=redstoneore\r\n");
                writer.write("74,0=glowingredstoneore\r\n");
                writer.write("75,0=redstonetorchoff\r\n");
                writer.write("76,0=redstonetorchon,redstonetorch\r\n");
                writer.write("79,0=ice\r\n");
                writer.write("80,0=snowblock\r\n");
                writer.write("81,0=cactus\r\n");
                writer.write("82,0=clay\r\n");
                writer.write("85,0=fence\r\n");
                writer.write("86,0=pumpkin\r\n");
                writer.write("87,0=redmossycobblestone,netherrack,netherrock,redcobble,bloodstone\r\n");
                writer.write("88,0=mud,soulsand,slowsand,nethersand\r\n");
                writer.write("89,0=glowstone,brittlegold,glowstoneblock\r\n");
                writer.write("91,0=jack-o-lantern,jackolantern\r\n");
                writer.write("98,0=stonebrick\r\n");
                writer.write("98,1=mossystonebrick\r\n");
                writer.write("98,2=crackedstonebrick\r\n");
                writer.write("99,0=redmushroomflesh\r\n");
                writer.write("99,1=hugeredmushroomcorner1\r\n");
                writer.write("99,2=hugeredmushroomside2\r\n");
                writer.write("99,3=hugeredmushroomcorner3\r\n");
                writer.write("99,4=hugeredmushroomside4\r\n");
                writer.write("99,5=hugeredmushroomtop5\r\n");
                writer.write("99,6=hugeredmushroomside6\r\n");
                writer.write("99,7=hugeredmushroomcorner7\r\n");
                writer.write("99,8=hugeredmushroomside8\r\n");
                writer.write("99,9=hugeredmushroomcorner9\r\n");
                writer.write("99,10=hugeredmushroomstem\r\n");
                writer.write("100,0=redmushroomflesh\r\n");
                writer.write("100,1=hugebrownmushroomcorner1\r\n");
                writer.write("100,2=hugebrownmushroomside2\r\n");
                writer.write("100,3=hugebrownmushroomcorner3\r\n");
                writer.write("100,4=hugebrownmushroomside4\r\n");
                writer.write("100,5=hugebrownmushroomtop5\r\n");
                writer.write("100,6=hugebrownmushroomside6\r\n");
                writer.write("100,7=hugebrownmushroomcorner7\r\n");
                writer.write("100,8=hugebrownmushroomside8\r\n");
                writer.write("100,9=hugebrownmushroomcorner9\r\n");
                writer.write("100,10=hugebrownmushroomstem\r\n");
                writer.write("101,0=ironbars\r\n");
                writer.write("102,0=glasspane,glasspanel\r\n");
                writer.write("103,0=melon,watermelon\r\n");
                writer.write("107,0=fencegate\r\n");
                writer.write("110,0=mycelium\r\n");
                writer.write("111,0=lilypad\r\n");
                writer.write("112,0=netherbrick\r\n");
                writer.write("113,0=netherbrickfence\r\n");
                writer.write("121,0=endstone,whitestone\r\n");
            } catch (Exception e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while creating " + itemsDatabase, e);
                BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                itemDatabaseEr = true;
            } finally {
                if (writer != null) {
                    try {
                        writer.flush();
                        writer.close();
                        BlockDoor.LOGGER.info("Successfully created New Item Database.");
                    } catch (IOException e) {
                        BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor error " + e);
                        BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                        itemDatabaseEr = true;
                    }
                }
                if (fwriter != null) {
                    try {
                        fwriter.close();
                    } catch (IOException e) {
                        BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor error " + e);
                        BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                        itemDatabaseEr = true;
                    }
                }
            }
        }
        if (!uzoneDatabase.exists()) {
            FileWriter fwriter = null;
            BufferedWriter writer = null;
            try {
                BlockDoor.LOGGER.info("BlockDoor Mob Database does not exist - creating it... ");
                fwriter = new FileWriter(uzoneDatabase);
                writer = new BufferedWriter(fwriter);
                writer.write("#Case Sensitive CraftBukkit Mob Class file name = names to use in game are comma seperated\r\n");
                writer.write("CraftPig = pig,craftpig\r\n");
                writer.write("CraftCow = cow,craftcow\r\n");
                writer.write("CraftChicken = chicken,craftchicken\r\n");
                writer.write("CraftSheep = sheep,craftsheep\r\n");
                writer.write("CraftSquid = squid,craftsquid\r\n");
                writer.write("CraftWolf = wolf,craftwolf\r\n");
                writer.write("CraftZombie = zombie,craftzombie\r\n");
                writer.write("CraftSpider = spider,craftspider\r\n");
                writer.write("CraftSlime = slime,craftslime\r\n");
                writer.write("CraftCreeper = creeper,craftcreeper\r\n");
                writer.write("CraftGiant = giant,craftgiant\r\n");
                writer.write("CraftPigZombie = pigzombie,craftpigzombie\r\n");
                writer.write("CraftGhast = ghast,craftghast\r\n");
                writer.write("CraftSkeleton = skeleton,craftskeleton\r\n");
                writer.write("CraftEnderman = enderman,craftenderman\r\n");
                writer.write("CraftCaveSpider = cavespider,craftcavespider\r\n");
                writer.write("CraftSilverfish = silverfish,craftsilverfish\r\n");
                writer.write("CraftEnderDragon = enderdragon,craftenderdragon\r\n");
                writer.write("CraftMushroomCow = mushroomcow,mooshroomcow,craftmushroomcow\r\n");
                writer.write("CraftSnowman = snowman,craftsnowman\r\n");
                writer.write("CraftBlaze = blaze,craftblaze\r\n");
                writer.write("CraftVillager = villager,testificate\r\n");
                writer.write("CraftMagmaCube = magmacube,craftmagmacube\r\n");
            } catch (Exception e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while creating " + uzoneDatabase, e);
            } finally {
                if (writer != null) {
                    try {
                        writer.flush();
                        writer.close();
                        BlockDoor.LOGGER.info("Successfully created Mob Database.");
                    } catch (IOException e) {
                        BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor error " + e);
                    }
                }
                if (fwriter != null) {
                    try {
                        fwriter.close();
                    } catch (IOException e) {
                        BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor error " + e);
                    }
                }
            }
        }
        reloadFile();
    }

    @SuppressWarnings("unused")
    public void reloadFile() {
        if (reload == true) {
            BlockDoor.LOGGER.info("Datafile reload initiated...");
            reInit();
        }

        if (oldDoorTXTDatabase.exists() || newDoorBinDatabase.exists()) {
            int doorCount = 0;
            int twostateCount = 0;
            int hybridDoorCount = 0;
            int triggerCount = 0;
            int zoneCount = 0;
            int redTrigCount = 0;
            SingleStateDoor d;
            HDoor hd;
            TwoStateDoor tsd;
            BlockTrigger t;
            MyTrigger mt;
            RedTrig r;
            PlayerZone z;
            MyZone mz;
            AllMobZone amz;
            AggressiveMobZone az;
            PassiveMobZone pz;
            AllLivingEntitiesZone ez;
            SelectedEntityZone uz;
            try {
                Scanner scanner;
                if (oldDoorTXTDatabase.exists())
                    scanner = new Scanner(oldDoorTXTDatabase);
                else {
                    String binDatabase = loadBinDatabase();
                    scanner = new Scanner(binDatabase);
                }

                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.startsWith("#") || line.length() == 0)
                        continue;
                    if (line.startsWith("DOOR:")) {
                        d = new SingleStateDoor(line);
                        if (d != null && d.creator != "FAILED") {
                            doors.add(d);
                            doorCount++;
                        }
                    }
                    else if (line.startsWith("HDOOR:")) {
                        hd = new HDoor(line);
                        if (hd != null && hd.creator != "FAILED") {
                            hdoor.add(hd);
                            hybridDoorCount++;
                        }
                    }
                    else if (line.startsWith("TWOSTATEDOOR:")) {
                        tsd = new TwoStateDoor(line);
                        if (tsd != null && tsd.creator != "FAILED") {
                            twostate.add(tsd);
                            twostateCount++;
                        }
                    }
                    else if (line.startsWith("TRIGGER:")) {
                        t = new BlockTrigger(line);
                        if (t != null && t.creator != "FAILED") {
                            allTriggers.add(t);
                            //triggers.add(t);
                            triggerCount++;
                        }
                    }
                    else if (line.startsWith("MYTRIGGER:")) {
                        mt = new MyTrigger(line);
                        if (mt != null && mt.creator != "FAILED") {
                            allTriggers.add(mt);
                            //mytriggers.add(mt);
                            triggerCount++;
                        }
                    }
                    else if (line.startsWith("REDTRIG:")) {
                        r = new RedTrig(line);
                        if (r != null && r.creator != "FAILED") {
                            allTriggers.add(r);
                            //redtrigs.add(r);
                            redTrigCount++;
                        }
                    }
                    else if (line.startsWith("ZONE:")) {
                        z = new PlayerZone(line);
                        if (z != null && z.zone_creator != "FAILED") {
                            allZones.add(z);
                            zoneCount++;
                        }
                    }
                    else if (line.startsWith("MYZONE:")) {
                        mz = new MyZone(line);
                        if (mz != null && mz.zone_creator != "FAILED") {
                            allZones.add(mz);
                            zoneCount++;
                        }
                    }
                    else if (line.startsWith("MZONE:")) {
                        amz = new AllMobZone(line);
                        if (amz != null && amz.zone_creator != "FAILED") {
                            allZones.add(amz);
                            zoneCount++;
                        }
                    }
                    else if (line.startsWith("AZONE:")) {
                        az = new AggressiveMobZone(line);
                        if (az != null && az.zone_creator != "FAILED") {
                            allZones.add(az);
                            zoneCount++;
                        }
                    }
                    else if (line.startsWith("PZONE:")) {
                        pz = new PassiveMobZone(line);
                        if (pz != null && pz.zone_creator != "FAILED") {
                            allZones.add(pz);
                            zoneCount++;
                        }
                    }
                    else if (line.startsWith("EZONE:")) {
                        ez = new AllLivingEntitiesZone(line);
                        if (ez != null && ez.zone_creator != "FAILED") {
                            allZones.add(ez);
                            zoneCount++;
                        }
                    }
                    else if (line.startsWith("UZONE:")) {
                        uz = new SelectedEntityZone(line);
                        if (uz != null && uz.zone_creator != "FAILED") {
                            allZones.add(uz);
                            zoneCount++;
                        }
                    }
                }
                scanner.close();
            } catch (Exception e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while reading " + newDoorsFile, e);
            }
            if (oldDoorTXTDatabase.exists()) {
                if (oldDoorTXTDatabase.renameTo(new File(directory, "blockdoors.bak"))) {
                    BlockDoor.LOGGER.log(Level.INFO, "Old BlockDoor database converted and renamed to: blockdoors.bak");
                    saveDatabase();
                }
                else {
                    BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor was unable to convert old text database.");
                    BlockDoor.LOGGER.log(Level.SEVERE, "Manually rename or deleted old database. (blockdoors.txt)");
                    saveDatabase();
                }

            }
            plugin.twostatedoorhelper.lock(); // lock all doors on load
            BlockDoor.LOGGER.log(Level.INFO, "BlockDoor loaded: ");
            BlockDoor.LOGGER.log(Level.INFO, doorCount + " Classic Door(s) " + hybridDoorCount + " Hybrid Door(s) " + twostateCount + " TwoState Door(s)");
            BlockDoor.LOGGER.log(Level.INFO, zoneCount + " Zone(s) " + triggerCount + " Trigger(s) " + redTrigCount + " Redstone Trigger(s)");
        }

        if (doorConfig.exists()) {
            max_ZoneSize = 20;
            max_DoorSize = 10;
            max_hdoorSize = 50;
            max_TwoStateSize = 20;
            overlapTwoStateDoors = false;
            overlapZones = false;
            overlapDoors = false;
            overlapHDoors = false;
            overlapTriggers = false;
            overlapRedstone = false;
            enableSpecialBlocks = false;
            enableConsoleCommands = false;
            Scanner scanner;
            try {
                scanner = new Scanner(doorConfig);
                String line;
                String[] split;
                while (scanner.hasNextLine()) {
                    line = scanner.nextLine();
                    if (line.startsWith("#") || line.length() == 0)
                        continue;
                    if (line.startsWith("max_zone_size=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                max_ZoneSize = Integer.parseInt(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Max Zone Size in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Max Zone Size in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("max_door_size=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                max_DoorSize = Integer.parseInt(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Max Door Size in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Max Door Size in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("max_twostate_size=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                max_TwoStateSize = Integer.parseInt(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Max Two State Door Size in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Max Two State Door Size in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("max_hdoor_size=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                max_hdoorSize = Integer.parseInt(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Max Hybrid State Door Size in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Max Two State Door Size in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_overlap_hdoors=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                overlapHDoors = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Hybrid Door overlap in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Max Two State Door Size in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_overlap_zones=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                overlapZones = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Zone overlap in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Zone overlap in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_overlap_doors=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                overlapDoors = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Door overlap in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Door overlap in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_overlap_twostatedoors=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                overlapTwoStateDoors = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Two State Door overlap in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Two State Door overlap in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_overlap_triggers=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                overlapTriggers = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Trigger overlap in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Trigger overlap in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_overlap_redstone=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                overlapRedstone = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Redstone overlap in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Redstone overlap in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_special_blocks=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                enableSpecialBlocks = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Special Blocks in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Special Blocks in config wrong. Default value used");
                        }
                    }
                    else if (line.startsWith("allow_console_commands=")) {
                        split = line.split("=");
                        if (split.length == 2) {
                            try {
                                enableConsoleCommands = Boolean.parseBoolean(split[1]);
                            } catch (Exception e) {
                                BlockDoor.LOGGER.log(Level.SEVERE, "Console command value in config wrong. Default value used");
                            }
                        }
                        else {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Console command value in config wrong. Default value used");
                        }
                    }
                }
                BlockDoor.LOGGER.info("BlockDoor config file finished loading...");
            } catch (FileNotFoundException e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while reading " + doorsConfig, e);
            }
        }
        if (itemDatabase.exists()) {
            Scanner scanner;
            int counter = 0;
            try {
                scanner = new Scanner(itemDatabase);
                String line, objectCode, objectNames;
                String[] split;
                int objectID, objectOffset;
                while (scanner.hasNextLine()) {
                    counter++;
                    line = scanner.nextLine();
                    if (line.startsWith("#") || line.length() == 0)
                        continue;
                    split = line.split("=");
                    objectCode = split[0];
                    objectNames = split[1];
                    split = objectCode.split(",");
                    //test for correct number values. Error out if wrong.
                    objectID = Integer.parseInt(split[0]);
                    objectOffset = Integer.parseInt(split[1]);
                    //***

                    //Make sure Primary type exists before adding subtypes, error if it doesnt
                    if (objectOffset != 0) {
                        //check for primary item type id. Not used right now. Maybe in the future
                        /*
                         * if(ItemsCodes.findItemByID(objectID+",0")==-1){
                         * BlockDoor.logger.log(Level.SEVERE,
                         * "No Primary type for item subtype");
                         * throw new Exception();
                         * }
                         */
                        if (plugin.itemcodeshelper.fillDatabase(objectNames, objectCode) != -1) {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Duplicate database entry");
                            throw new Exception();
                        }
                    }
                    else {
                        if (plugin.itemcodeshelper.findItemByID(objectCode) != -1) {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Duplicate database entry");
                            throw new Exception();
                        }
                        if (plugin.itemcodeshelper.fillDatabase(objectNames, objectCode) != -1) {
                            BlockDoor.LOGGER.log(Level.SEVERE, "Duplicate database entry");
                            throw new Exception();
                        }
                    }
                }
                BlockDoor.LOGGER.info("BlockDoor Item Database finished loading...");
            } catch (FileNotFoundException e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while reading " + itemsDatabase, e);
                BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                itemDatabaseEr = true;
            } catch (Exception e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Error on line " + counter + " of item database");
                BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                itemDatabaseEr = true;
            }
        }
        else {
            BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor item database Not Found");
            BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
            itemDatabaseEr = true;
        }
        if (uzoneDatabase.exists()) {
            Scanner scanner;
            int counter = 0;
            try {
                scanner = new Scanner(uzoneDatabase);
                String line, mobClassString, mobNames;
                String[] split;
                while (scanner.hasNextLine()) {
                    counter++;
                    line = scanner.nextLine();
                    if (line.startsWith("#") || line.length() == 0)
                        continue;
                    split = line.split("=");
                    if (split.length != 2)
                        throw new Exception();
                    mobClassString = split[0].trim();
                    mobNames = split[1];
                    split = mobNames.split(",");
                    String classPath = "org.bukkit.craftbukkit.entity.";
                    Class<?> mobClass = Class.forName(classPath + mobClassString);
                    if (mobs.get(mobClass) == null)
                        mobs.put(mobClass, new ArrayList<String>());
                    for(String name : split) {
                        mobs.get(mobClass).add(name.trim().toLowerCase());
                    }
                }
                BlockDoor.LOGGER.info("BlockDoor Mob Database finished loading...");
            } catch (ClassNotFoundException e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Invalid Mob database entry");
                BlockDoor.LOGGER.log(Level.SEVERE, "Error on line " + counter + " of Mob database");
                BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                uzoneDatabaseEr = true;
            } catch (FileNotFoundException e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while reading " + uzoneDatabase, e);
                BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                uzoneDatabaseEr = true;
            } catch (Exception e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "Exception while reading " + uzoneDatabase, e);
                BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
                uzoneDatabaseEr = true;
            }
            System.out.println("Blockdoor Finished loading " + counter + " mobs...");
        }
        else {
            BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor Mob database Not Found");
            BlockDoor.LOGGER.log(Level.SEVERE, "Using internal database...");
            uzoneDatabaseEr = true;
        }
        if (reload == true) {
            BlockDoor.LOGGER.info("Datafile Reload completed...");
            reload = false;
        }
    }

    private String loadBinDatabase() {
        try {
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(newDoorBinDatabase));
            String input = (String) inputStream.readObject();
            inputStream.close();
            return input;
        } catch (FileNotFoundException e) {
            BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor Cant Find " + newDoorBinDatabase.getAbsolutePath());
        } catch (IOException e) {
            BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor Access " + newDoorBinDatabase.getAbsolutePath());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return "";
    }

    public void deleteLinks(String doorName, String player) {
        //Delete links for all Triggers
        for(Trigger trigger : allTriggers){
            for(Link link : trigger.links) {
                if (link.link_name.equalsIgnoreCase(doorName) && link.link_creator.equals(player)) {
                    trigger.links.remove(link);
                    break;
                }
            }
        }
        //Delete links for all zone types
        for(Zone az : allZones) {
            for(Link link : az.links) {
                if (link.link_name.equalsIgnoreCase(doorName) && link.link_creator.equals(player)) {
                    az.links.remove(link);
                    break;
                }
            }
        }
        saveDatabase();
    }

    public int saveDatabase() {
        StringBuffer databin = new StringBuffer();
        if (newDoorBinDatabase.exists()) { // Check if the database exists, if it does save all blockdoor objects to file.
            int count = 0;
            for(int i = 0; i < doors.size(); i++) {
                databin.append(doors.get(i).toString() + "\n");
                count++;
            }
            for(int i = 0; i < twostate.size(); i++) {
                databin.append(twostate.get(i).toString() + "\n");
                count++;
            }
            for(int i = 0; i < hdoor.size(); i++) {
                databin.append(hdoor.get(i).toString() + "\n");
                count++;
            }
            for(int i = 0; i < allTriggers.size(); i++){
                databin.append(allTriggers.get(i).toString() + "\n");
                count++;
            }
            for(Zone az : allZones) {
                if (az.zone_Type.equals("ZONE")) {
                    databin.append(((PlayerZone) az).toString() + "\n");
                }
                else if (az.zone_Type.equals("MYZONE")) {
                    databin.append(((MyZone) az).toString() + "\n");
                }
                else if (az.zone_Type.equals("EZONE")) {
                    databin.append(((AllLivingEntitiesZone) az).toString() + "\n");
                }
                else if (az.zone_Type.equals("AZONE")) {
                    databin.append(((AggressiveMobZone) az).toString() + "\n");
                }
                else if (az.zone_Type.equals("MZONE")) {
                    databin.append(((AllMobZone) az).toString() + "\n");
                }
                else if (az.zone_Type.equals("PZONE")) {
                    databin.append(((PassiveMobZone) az).toString() + "\n");
                }
                else if (az.zone_Type.equals("UZONE")) {
                    databin.append(((SelectedEntityZone) az).toString() + "\n");
                }
                count++;
            }
            ObjectOutputStream outputStream = null;
            try {
                outputStream = new ObjectOutputStream(new FileOutputStream(newDoorBinDatabase));
                outputStream.writeObject(databin.toString());
            } catch (IOException e) {
                BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor can not Access " + newDoorBinDatabase.getAbsolutePath(), e);
            } finally {
                try {
                    if (outputStream != null) {
                        outputStream.flush();
                        outputStream.close();
                    }
                } catch (IOException ex) {
                    BlockDoor.LOGGER.log(Level.SEVERE, "BlockDoor can not Access " + newDoorBinDatabase.getAbsolutePath(), ex);
                }
            }
            return count;
        }
        else
            return -1;
    }

    private void reInit() {

        //doors array
        doors.clear();
        hdoor.clear();
        twostate.clear();

        //trigger array
        allTriggers.clear();

        //Item database array
        itemcodes.clear();

        //zone occupancy tracker array
        zoneOccupancyList.clear();

        //zone arrays
        allZones.clear();

        //config variables
        max_DoorSize = 10;
        max_ZoneSize = 20;
        max_TwoStateSize = 20;
        max_hdoorSize = 50;
        overlapZones = false;
        overlapDoors = false;
        overlapTwoStateDoors = false;
        overlapHDoors = false;
        overlapTriggers = false;
        overlapRedstone = false;
        enableConsoleCommands = false;

        //Item database error control variable
        itemDatabaseEr = false;

    }

    /**
     * @return the max_DoorSize
     */
    public int getMax_DoorSize() {
        return max_DoorSize;
    }

    /**
     * @return the max_hdoorSize
     */
    public int getMax_hdoorSize() {
        return max_hdoorSize;
    }

    /**
     * @return the overlapHDoors
     */
    public boolean isOverlapHDoors() {
        return overlapHDoors;
    }

    /**
     * @return the max_TwoStateSize
     */
    public int getMax_TwoStateSize() {
        return max_TwoStateSize;
    }

    /**
     * @return the max_ZoneSize
     */
    public int getMax_ZoneSize() {
        return max_ZoneSize;
    }

    /**
     * @return the overlapZones
     */
    public boolean isOverlapZones() {
        return overlapZones;
    }

    /**
     * @return the overlapDoors
     */
    public boolean isOverlapDoors() {
        return overlapDoors;
    }

    /**
     * @return the overlapTwoStateDoors
     */
    public boolean isOverlapTwoStateDoors() {
        return overlapTwoStateDoors;
    }

    /**
     * @return the overlapTriggers
     */
    public boolean isOverlapTriggers() {
        return overlapTriggers;
    }

    /**
     * @return the overlapRedstone
     */
    public boolean isOverlapRedstone() {
        return overlapRedstone;
    }

    /**
     * @return the enableSpecialBlocks
     */
    public boolean isEnableSpecialBlocks() {
        return enableSpecialBlocks;
    }

    /**
     * @return the enableConsoleCommands
     */
    public boolean isEnableConsoleCommands() {
        return enableConsoleCommands;
    }

    /**
     * @return the itemDatabaseEr
     */
    public boolean isItemDatabaseEr() {
        return itemDatabaseEr;
    }

    /**
     * @return the uzoneDatabaseEr
     */
    public boolean isUzoneDatabaseEr() {
        return uzoneDatabaseEr;
    }

    /**
     * @param itemDatabaseEr
     *            the itemDatabaseEr to set
     */
    public void setItemDatabaseEr(boolean itemDatabaseEr) {
        this.itemDatabaseEr = itemDatabaseEr;
    }

    /**
     * @return the permissionsSet
     */
    public boolean isPermissionsSet() {
        return permissionsSet;
    }

    /**
     * @param permissionsSet
     *            the permissionsSet to set
     */
    public void setPermissionsSet(boolean permissionsSet) {
        this.permissionsSet = permissionsSet;
    }

    /**
     * @return the error
     */
    public boolean isError() {
        return error;
    }

    /**
     * @param error
     *            the error to set
     */
    public void setError(boolean error) {
        this.error = error;
    }

    /**
     * @param reload
     *            the reload to set
     */
    public void setReload(boolean reload) {
        this.reload = reload;
    }

    /**
     * @return the newDoorsFile
     */
    public String getDoorsLoc() {
        return newDoorsFile;
    }
}
package plugin.arcwolf.blockdoor.listeners;

// A kind of custom listener for LivingEntities teleporting, dying or walking in and out of zones.

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.craftbukkit.entity.*;
import org.bukkit.entity.*;

import plugin.arcwolf.blockdoor.AllZonesList;
import plugin.arcwolf.blockdoor.AllZonesListHelper;
import plugin.arcwolf.blockdoor.BlockDoor;
import plugin.arcwolf.blockdoor.Utils.DataWriter;
import plugin.arcwolf.blockdoor.Zones.*;

public class ZoneMobWatcher implements Runnable {

    private BlockDoor plugin;
    private DataWriter dataWriter;
    private List<AllZonesList> allZonesList;
    private AllZonesListHelper allzoneslisthelper;

    //Map of all entities in the server
    private Map<Integer, LivingEntity> eList = new HashMap<Integer, LivingEntity>();

    private int findLiving;
    private volatile boolean shouldToggle = false;

    public ZoneMobWatcher() {
        plugin = BlockDoor.plugin;
        dataWriter = plugin.datawriter;
        allzoneslisthelper = new AllZonesListHelper();
        allZonesList = dataWriter.zoneOccupancyList;
    }

    /*
     * Cycles through all the zones and tests for entity occupancy.
     * This method is on a synchronized thread
     */
    public void run() {
        shouldToggle = false;
        boolean hasPermission;
        clearDespawns();
        LivingEntity e;
        for(Zone az : dataWriter.allZones) {
            buildZoneChunkMap(az);
            for(Entry<Chunk, Chunk> chunk : az.zoneChunk.entrySet()) {
                for(Entity ent : chunk.getKey().getEntities()) {
                    e = null;
                    if (ent instanceof LivingEntity)
                        e = (LivingEntity) ent;
                    else {
                        continue;
                    }
                    hasPermission = true;
                    // Checks for a players usezones permissions and sets hasPermissions to false if the player does not have permission to use zones.
                    if (e instanceof Player && !(plugin.playerHasPermission((Player) e, "blockdoor.usezones") || plugin.playerHasPermission((Player) e, "*")))
                        hasPermission = false;

                    // Check for player and permission
                    if (hasPermission && e instanceof Player) {
                        //Player detection zone
                        if (az.zone_Type.equals("ZONE")) {
                            testZones(az, e);
                        }

                        // Player detection for My Zones 
                        if (((Player) e).getName().equals(az.zone_creator) || (plugin.playerHasPermission((Player) e, "blockdoor.admin.myzone"))) {
                            if (az.zone_Type.equals("MYZONE"))
                                testZones(az, e);
                        }
                    }
                    // Zone detection for selected entities
                    if (!plugin.datawriter.isUzoneDatabaseEr() && az.zone_Type.equals("UZONE") && uzoneDetect(e, (SelectedEntityZone) az)) {
                        testZones(az, e);
                    }
                    else if (plugin.datawriter.isUzoneDatabaseEr() && az.zone_Type.equals("UZONE") && uzoneInteralDetect(e, (SelectedEntityZone) az)) {
                        testZones(az, e);
                    }
                    // Zone detection for Passive mobs
                    if (!(e instanceof Player) && az.zone_Type.equals("PZONE") && (isPassiveMob(e))) {
                        testZones(az, e);
                    }

                    // Zone detection for Aggressive mobs
                    if (!(e instanceof Player) && az.zone_Type.equals("AZONE") && isAggressiveMob(e)) {
                        testZones(az, e);
                    }

                    // Zone detection for Aggressive and Passive mobs combined
                    if (!(e instanceof Player) && az.zone_Type.equals("MZONE")) {
                        testZones(az, e);
                    }

                    // Zone detection for Aggressive mobs, passive mobs and players
                    if (hasPermission && az.zone_Type.equals("EZONE")) {
                        testZones(az, e);
                    }
                }
            }
        }
    }

    //Gets a list of all chunks that a zone occupies and sets the zone's Chunk map to contain those chunks
    private void buildZoneChunkMap(Zone zone) {
        try {
            World world = plugin.getWorld(zone.zone_world);
            Map<Chunk, Chunk> surroundingChunks;
            if (zone.world == null)
                zone.world = world;
            if (!zone.isInitialized()) {
                zone.zoneChunk.clear();
                for(int x = zone.zone_start_x; x <= zone.zone_end_x; x++) {
                    for(int y = zone.zone_start_y; y <= zone.zone_end_y; y++) {
                        for(int z = zone.zone_start_z; z <= zone.zone_end_z; z++) {
                            surroundingChunks = getSurroundingChunks(world.getChunkAt(new Location(world, x, y, z)));
                            surroundingChunks.keySet().removeAll(zone.zoneChunk.keySet());
                            zone.zoneChunk.putAll(surroundingChunks);
                        }
                    }
                }
                zone.setInitialized(true);
            }
        } catch (Exception e) {} // Do Nothing
        //************************
    }

    // surrounding 
    private Map<Chunk, Chunk> getSurroundingChunks(Chunk startChunk) {
        int chunkX = startChunk.getX();
        int chunkZ = startChunk.getZ();
        World world = startChunk.getWorld();
        Map<Chunk, Chunk> tmp = new HashMap<Chunk, Chunk>();
        Chunk tempChunk;
        for(int x = -1; x < 2; x++) {
            for(int z = -1; z < 2; z++) {
                tempChunk = world.getChunkAt(chunkX + x, chunkZ + z);
                tmp.put(tempChunk, tempChunk);
            }
        }
        return tmp;
    }

    private void testZones(Zone z, LivingEntity e) {
        Location l = e.getLocation();
        World eWorld = l.getWorld();
        int eHealth = e.getHealth();
        findLiving = (allzoneslisthelper.findLiving(z, e));
        z.world = plugin.getWorld(z.zone_world);
        if (z.coordsSet && z.isInZone(l) && eHealth != 0 && z.world == eWorld) {
            //ENTERING ZONE
            if (!eList.containsKey(e.getEntityId()))
                eList.put(e.getEntityId(), e);
            if (z.occupants == 0) {
                allZonesList.add(new AllZonesList(z, e));
                z.processLinks();
                updateOccupants(z);
            }
            else if (z.occupants > 0) {
                if (findLiving == -1) {
                    allZonesList.add(new AllZonesList(z, e));
                }
                updateOccupants(z);
                shouldToggle = false;
            }
        }
        else if (z.coordsSet && z.isInZone(l) && (eHealth == 0 && (findLiving != -1) && z.world == eWorld)) {
            //DEATH WHILE IN ZONE
            eList.remove(e.getEntityId());
            if (z.occupants > 0) {
                if (findLiving != -1) {
                    allZonesList.remove(findLiving);
                }
                updateOccupants(z);
                if (z.occupants == 0) {
                    shouldToggle = true;
                }
            }
            if (z.occupants == 0 && shouldToggle && z.world == eWorld) {
                updateOccupants(z);
                z.processLinks();
                shouldToggle = false;
            }
        }
        else if (z.coordsSet && !z.isInZone(l) && (findLiving != -1) && z.world == eWorld) {
            //LEAVING ZONE
            eList.remove(e.getEntityId());
            if (z.occupants > 0) {
                if (findLiving != -1) {
                    allZonesList.remove(findLiving);
                }
                updateOccupants(z);
                if (z.occupants == 0) {
                    shouldToggle = true;
                }
            }
            if (z.occupants == 0 && shouldToggle) {
                updateOccupants(z);
                z.processLinks();
                shouldToggle = false;
            }
        }
    }

    private void updateOccupants(Zone z) {
        z.occupants = allzoneslisthelper.countOccupants(z);
    }

    private boolean isAggressiveMob(LivingEntity e) {
        return e instanceof Monster || e instanceof Ghast || e instanceof Slime;
    }

    private boolean isPassiveMob(LivingEntity e) {
        return e instanceof Animals || e instanceof Snowman || e instanceof WaterMob || e instanceof NPC;
    }

    private boolean uzoneDetect(LivingEntity e, SelectedEntityZone uz) {
        Map<Class<?>, List<String>> mobMap = plugin.datawriter.mobs;
        if (e instanceof Player) {
            Player p = (Player) e;
            if (p.getName().equals(uz.uzone_trigger))
                return true;
        }
        if (mobMap.get(e.getClass()) != null && mobMap.get(e.getClass()).contains(uz.uzone_trigger.trim().toLowerCase())) { return true; }
        return false;
    }

    private boolean uzoneInteralDetect(LivingEntity e, SelectedEntityZone uz) {
        if ((uz.uzone_trigger.equalsIgnoreCase("CraftPig") || uz.uzone_trigger.equalsIgnoreCase("Pig")) && e instanceof CraftPig)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftCow") || uz.uzone_trigger.equalsIgnoreCase("Cow")) && e instanceof CraftCow)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftChicken") || uz.uzone_trigger.equalsIgnoreCase("Chicken")) && e instanceof CraftChicken)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftSheep") || uz.uzone_trigger.equalsIgnoreCase("Sheep")) && e instanceof CraftSheep)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftSquid") || uz.uzone_trigger.equalsIgnoreCase("Squid")) && e instanceof CraftSquid)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftWolf") || uz.uzone_trigger.equalsIgnoreCase("Wolf")) && e instanceof CraftWolf)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftZombie") || uz.uzone_trigger.equalsIgnoreCase("Zombie")) && e instanceof CraftZombie)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftSpider") || uz.uzone_trigger.equalsIgnoreCase("Spider")) && e instanceof CraftSpider)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftSlime") || uz.uzone_trigger.equalsIgnoreCase("Slime")) && e instanceof CraftSlime)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftCreeper") || uz.uzone_trigger.equalsIgnoreCase("Creeper")) && e instanceof CraftCreeper)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftGiant") || uz.uzone_trigger.equalsIgnoreCase("Giant")) && e instanceof CraftGiant)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftPigZombie") || uz.uzone_trigger.equalsIgnoreCase("PigZombie")) && e instanceof CraftPigZombie)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftGhast") || uz.uzone_trigger.equalsIgnoreCase("Ghast")) && e instanceof CraftGhast)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftSkeleton") || uz.uzone_trigger.equalsIgnoreCase("Skeleton")) && e instanceof CraftSkeleton)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftEnderman") || uz.uzone_trigger.equalsIgnoreCase("Enderman")) && e instanceof CraftEnderman)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftCaveSpider") || uz.uzone_trigger.equalsIgnoreCase("CaveSpider")) && e instanceof CraftCaveSpider)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftSilverfish") || uz.uzone_trigger.equalsIgnoreCase("Silverfish")) && e instanceof CraftSilverfish)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftEnderDragon") || uz.uzone_trigger.equalsIgnoreCase("EnderDragon")) && e instanceof CraftEnderDragon)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftMushroomCow") || uz.uzone_trigger.equalsIgnoreCase("Mooshroom") || uz.uzone_trigger.equalsIgnoreCase("MushroomCow")) && e instanceof CraftMushroomCow)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftSnowman") || uz.uzone_trigger.equalsIgnoreCase("Snowman")) && e instanceof CraftSnowman)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftBlaze") || uz.uzone_trigger.equalsIgnoreCase("Blaze")) && e instanceof CraftBlaze)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftVillager") || uz.uzone_trigger.equalsIgnoreCase("Villager") || uz.uzone_trigger.equalsIgnoreCase("Testificate")) && e instanceof CraftVillager)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftMagmaCube") || uz.uzone_trigger.equalsIgnoreCase("MagmaCube")) && e instanceof CraftMagmaCube)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftOcelot") || uz.uzone_trigger.equalsIgnoreCase("Ocelot")) && e instanceof CraftOcelot)
            return true;
        else if ((uz.uzone_trigger.equalsIgnoreCase("CraftIronGolem") || uz.uzone_trigger.equalsIgnoreCase("IronGolem")) && e instanceof CraftIronGolem)
            return true;
        else if (e instanceof Player) {
            Player p = (Player) e;
            if (p.getName().equals(uz.uzone_trigger))
                return true;
        }
        return false;
    }

    private void clearDespawns() {
        List<Entity> despawns = new ArrayList<Entity>();
        List<Integer> keyList = new ArrayList<Integer>();
        int index;

        for(Entry<Integer, LivingEntity> e : eList.entrySet())
            if (e.getValue().isDead()) keyList.add(e.getKey());

        for(Integer i : keyList)
            eList.remove(i);

        for(int azlIdx = 0; azlIdx < allZonesList.size(); azlIdx++)
            if (!findLivingEntity(allZonesList.get(azlIdx).entity)) despawns.add(allZonesList.get(azlIdx).entity);

        for(Entity dsp : despawns) {
            index = allzoneslisthelper.findZonedEntity(dsp);
            updateZone(allZonesList.get(index).zone);
            allZonesList.remove(index);
        }
    }

    private boolean findLivingEntity(Entity entity) {
        LivingEntity ent = null;
        for(Entry<Integer, LivingEntity> e : eList.entrySet()) {
            ent = e.getValue();
            if (ent == entity) { return true; }
        }
        return false;
    }

    private void updateZone(Zone z) {
        int occupancy = allzoneslisthelper.countOccupants(z);
        if (occupancy == 1) {
            z.occupants = 0;
            z.processLinks();
        }
        else
            z.occupants--;
    }
}

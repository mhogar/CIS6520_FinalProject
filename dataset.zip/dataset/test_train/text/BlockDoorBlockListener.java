package plugin.arcwolf.blockdoor.listeners;

import java.util.List;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.block.LeavesDecayEvent;

import plugin.arcwolf.blockdoor.BlockDoor;
import plugin.arcwolf.blockdoor.BlockDoor.Locks;
import plugin.arcwolf.blockdoor.Doors.TwoStateDoor;
import plugin.arcwolf.blockdoor.Triggers.BlockTrigger;
import plugin.arcwolf.blockdoor.Triggers.MyTrigger;
import plugin.arcwolf.blockdoor.Triggers.RedTrig;
import plugin.arcwolf.blockdoor.Triggers.Trigger;
import plugin.arcwolf.blockdoor.Utils.BlockDoorSettings;
import plugin.arcwolf.blockdoor.Utils.DataWriter;
import plugin.arcwolf.blockdoor.Utils.SpecialCaseCheck;

@SuppressWarnings("unused")
public class BlockDoorBlockListener implements Listener {

    private BlockDoor plugin;
    private DataWriter dataWriter;

    public BlockDoorBlockListener() {
        plugin = BlockDoor.plugin;
        dataWriter = plugin.datawriter;
    }

    @EventHandler
    public void onBlockPistonRetract(BlockPistonRetractEvent event) {
        if (event.isCancelled())
            return;
        int blockX = event.getRetractLocation().getBlockX();
        int blockY = event.getRetractLocation().getBlockY();
        int blockZ = event.getRetractLocation().getBlockZ();
        String inWorld = event.getBlock().getWorld().getName();

        if (event.isSticky()) {
            if (Math.abs(plugin.twostatedoorhelper.findCoordinates(blockX, blockY, blockZ, inWorld)) != 2147483647 && event.getRetractLocation().getBlock().getTypeId() != 0) {
                //BlockDoor.logger.info("retract canceled "+ TwoStateDoor.findCoordinates(blockX, blockY, blockZ, inWorld));
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onBlockPistonExtend(BlockPistonExtendEvent event) {
        if (event.isCancelled())
            return;
        int blockX, blockY, blockZ;
        String inWorld;

        breakLoop:
        for(Block b : event.getBlocks()) {
            blockX = b.getLocation().getBlockX();
            blockY = b.getLocation().getBlockY();
            blockZ = b.getLocation().getBlockZ();
            inWorld = b.getLocation().getWorld().getName();
            if (Math.abs(plugin.twostatedoorhelper.findCoordinates(blockX, blockY, blockZ, inWorld)) != 2147483647) {
                //BlockDoor.logger.info("extend canceled "+ TwoStateDoor.findCoordinates(blockX, blockY, blockZ, inWorld));
                event.setCancelled(true);
                break breakLoop;
            }
        }
    }

    //Listens for redstone change events and toggles any redtrig's that are at the event site.
    @EventHandler
    public void onBlockRedstoneChange(BlockRedstoneEvent event) {
        int x_Pos = event.getBlock().getLocation().getBlockX();
        int y_Pos = event.getBlock().getLocation().getBlockY();
        int z_Pos = event.getBlock().getLocation().getBlockZ();
        String trig_World = event.getBlock().getLocation().getWorld().getName();
        for(Trigger r : dataWriter.allTriggers) {
            if (r.trigger_Type.equals("REDTRIG") && r.coordsSet && r.trigger_x == x_Pos && r.trigger_y == y_Pos && r.trigger_z == z_Pos && r.trigger_world.equals(trig_World)) {
                r.world = event.getBlock().getLocation().getWorld();
                r.processLinks();
            }
        }
    }

    //Listens for physics events relating to twostate doors and hdoors. Prevents popping while door is being created.
    @EventHandler
    public void onBlockPhysics(BlockPhysicsEvent event) {
        if (event.isCancelled()) return;
        int blockID = event.getBlock().getTypeId();
        int blockX = event.getBlock().getLocation().getBlockX();
        int blockY = event.getBlock().getLocation().getBlockY();
        int blockZ = event.getBlock().getLocation().getBlockZ();
        String inWorld = event.getBlock().getLocation().getWorld().getName();
        if (SpecialCaseCheck.isWatchedBlock(blockID)) {
            int tsID = Math.abs(plugin.twostatedoorhelper.findCoordinates(blockX, blockY, blockZ, inWorld));
            if (Math.abs(tsID) != 2147483647) {
                if (plugin.datawriter.doorPhysics.containsKey(plugin.datawriter.twostate.get(tsID))) {
                    if(blockID==27) System.out.println("FIRED");
                    event.setCancelled(true);
                }
            }
            else {
                int hdID = plugin.hdoorhelper.findCoordinates(blockX, blockY, blockZ, inWorld);
                if (hdID != -1 && plugin.datawriter.doorPhysics.containsKey(plugin.datawriter.hdoor.get(hdID)))
                    event.setCancelled(true);
            }
        }
    }

    // temporary fix until I get around to incorporating snow forming on a twostate door.
    @EventHandler
    public void onBlockForm(BlockFormEvent event) {
        if (event.isCancelled())
            return;
        event.setCancelled(otherChecks(event.getBlock()));
    }

    @EventHandler
    public void onBlockBurn(BlockBurnEvent event) {
        if (event.isCancelled())
            return;
        event.setCancelled(otherChecks(event.getBlock()));
    }

    @EventHandler
    public void onBlockIgnite(BlockIgniteEvent event) {
        if (event.isCancelled())
            return;
        event.setCancelled(otherChecks(event.getBlock()));
    }

    @EventHandler
    public void onLeavesDecay(LeavesDecayEvent event) {
        if (event.isCancelled())
            return;
        event.setCancelled(otherChecks(event.getBlock()));
    }

    // Check for water flow in a twostate door and save its state
    // Until such time as I can figure out how to correctly handle all the little quirks of flowing
    // liquids this is disabled.
    @EventHandler
    public void onBlockFromTo(BlockFromToEvent event) {
        if (event.isCancelled())
            return;
        event.setCancelled(otherChecks(event.getBlock()));
        /*
         * int blockX = event.getBlock().getLocation().getBlockX();
         * int blockY = event.getBlock().getLocation().getBlockY();
         * int blockZ = event.getBlock().getLocation().getBlockZ();
         * String world = event.getBlock().getWorld().getName();
         * //World blockWorld = event.getBlock().getWorld();
         * int twoStateid = TwoStateDoor.findCoordinates(blockX, blockY, blockZ,
         * world);
         * if(twoStateid!=2147483647)
         * {
         * twoStateid = Math.abs(twoStateid);
         * if(BlockDoor.twostate.get(twoStateid).locks==Locks.UNLOCKED)
         * 
         * if(!BlockDoor.twostate.get(twoStateid).isOpen)
         * {
         * if(BlockDoor.twostate.get(twoStateid).coordsSet)
         * {
         * int stateIndex = DoorFirstState.findCoordinates(twoStateid, blockX,
         * blockY, blockZ);
         * BlockDoor.twostate.get(twoStateid).stateOneContents.get(stateIndex).
         * blockID = event.getBlock().getTypeId();
         * BlockDoor.twostate.get(twoStateid).stateOneContents.get(stateIndex).
         * offset = event.getBlock().getData();
         * }
         * else
         * {
         * event.setCancelled(true);
         * }
         * }
         * else
         * {
         * if(BlockDoor.twostate.get(twoStateid).coordsSet)
         * {
         * int stateIndex = DoorSecondState.findCoordinates(twoStateid, blockX,
         * blockY, blockZ);
         * BlockDoor.twostate.get(twoStateid).stateTwoContents.get(stateIndex).
         * blockID = event.getBlock().getTypeId();
         * BlockDoor.twostate.get(twoStateid).stateTwoContents.get(stateIndex).
         * offset = event.getBlock().getData();
         * }
         * else
         * {
         * event.setCancelled(true);
         * }
         * }
         * else
         * event.setCancelled(true);
         * }
         */
    }

    private boolean otherChecks(Block eventBlock) {
        int blockX = eventBlock.getLocation().getBlockX();
        int blockY = eventBlock.getLocation().getBlockY();
        int blockZ = eventBlock.getLocation().getBlockZ();
        String world = eventBlock.getWorld().getName();
        int twoStateid = plugin.twostatedoorhelper.findCoordinates(blockX, blockY, blockZ, world);
        if (twoStateid != 2147483647) { return true; }
        return false;
    }

    //Used for Indirectly powered triggers.
    private void indirectlyPoweredTrigger(Block block) {
        int x_Pos = block.getLocation().getBlockX();
        int y_Pos = block.getLocation().getBlockY();
        int z_Pos = block.getLocation().getBlockZ();
        String trig_World = block.getLocation().getWorld().getName();
        for(Trigger r : dataWriter.allTriggers) {
            if (r.trigger_Type.equals("REDTRIG") && r.coordsSet && r.trigger_x == x_Pos && r.trigger_y == y_Pos && r.trigger_z == z_Pos && r.trigger_world.equals(trig_World)) {
                r.world = block.getLocation().getWorld();
                r.processLinks();
            }
        }
    }

    //Listens for block place events and checks for Door states to update
    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (event.isCancelled())
            return;
        BlockDoorSettings settings = BlockDoorSettings.getSettings(event.getPlayer());
        if (settings.command.equalsIgnoreCase("hdoor")) {
            plugin.hdoorhelper.addBlock(event, settings);
        }
        else {
            plugin.twostatedoorhelper.addBlock(event, settings);
        }
    }

    //listens for block break events and removes triggers that are at the event site.
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.isCancelled())
            return;
        BlockDoorSettings settings = BlockDoorSettings.getSettings(event.getPlayer());
        if (settings.command.equalsIgnoreCase("hdoor")) {
            plugin.hdoorhelper.removeBlock(event, settings);
        }
        else {
            plugin.twostatedoorhelper.removeBlock(event, settings);
        }

        int x_Pos = event.getBlock().getLocation().getBlockX();
        int y_Pos = event.getBlock().getLocation().getBlockY();
        int z_Pos = event.getBlock().getLocation().getBlockZ();
        String trig_World = event.getBlock().getLocation().getWorld().getName();
        String player = event.getPlayer().getName();
        int triggerCount = 0;
        for(Trigger trigger : dataWriter.allTriggers) {
            if (trigger.trigger_Type.equals("TRIGGER") && trigger.trigger_x == x_Pos && trigger.trigger_y == y_Pos && trigger.trigger_z == z_Pos && trigger.trigger_world.equals(trig_World)) {
                triggerCount++;
            }
        }
        eventCanceled:
        for(int i = 0; i < triggerCount; i++) {
            startAgain:
            for(Trigger t : dataWriter.allTriggers) {
                if (t.trigger_Type.equals("TRIGGER") && t.trigger_x == x_Pos && t.trigger_y == y_Pos && t.trigger_z == z_Pos && t.trigger_world.equals(trig_World)) {
                    if (plugin.playerHasPermission(event.getPlayer(), "blockdoor.player.breaktriggers") || plugin.playerHasPermission(event.getPlayer(), "blockdoor.admin.breaktriggers")) {
                        if (t.creator.equals(event.getPlayer().getName()) || (plugin.playerHasPermission(event.getPlayer(), "blockdoor.admin.breaktriggers"))) {
                            BlockTrigger trig = (BlockTrigger) plugin.triggerhelper.findCoordinates("TRIGGER", x_Pos, y_Pos, z_Pos, trig_World);
                            event.getPlayer().sendMessage("Trigger " + ChatColor.GREEN + trig.trigger_name + ChatColor.WHITE + " by " + ChatColor.GREEN + trig.creator + ChatColor.WHITE + " removed.");
                            dataWriter.allTriggers.remove(trig);
                            dataWriter.saveDatabase();
                            break startAgain;
                        }
                        else if (!t.creator.equals(player)) {
                            event.getPlayer().sendMessage(ChatColor.RED + "You can only break your own BlockDoor triggers.");
                            event.setCancelled(true);
                            break eventCanceled;
                        }
                        else {
                            event.getPlayer().sendMessage(ChatColor.RED + "You dont have permissions to break BlockDoor triggers.");
                            event.setCancelled(true);
                            break eventCanceled;
                        }
                    }
                    else {
                        event.getPlayer().sendMessage(ChatColor.RED + "You dont have permissions to break BlockDoor triggers.");
                        event.setCancelled(true);
                        break eventCanceled;
                    }
                }
            }
        }
        triggerCount = 0;
        for(Trigger mytrigger : dataWriter.allTriggers) {
            if (mytrigger.trigger_Type.equals("MYTRIGGER") && mytrigger.trigger_x == x_Pos && mytrigger.trigger_y == y_Pos && mytrigger.trigger_z == z_Pos && mytrigger.trigger_world.equals(trig_World)) {
                triggerCount++;
            }
        }
        eventCanceled:
        for(int i = 0; i < triggerCount; i++) {
            startAgain:
            for(Trigger mt : dataWriter.allTriggers) {
                if (mt.trigger_Type.equals("MYTRIGGER") && mt.trigger_x == x_Pos && mt.trigger_y == y_Pos && mt.trigger_z == z_Pos && mt.trigger_world.equals(trig_World)) {
                    if (plugin.playerHasPermission(event.getPlayer(), "blockdoor.player.breaktriggers") || plugin.playerHasPermission(event.getPlayer(), "blockdoor.admin.breaktriggers")) {
                        if (mt.creator.equals(event.getPlayer().getName()) || (plugin.playerHasPermission(event.getPlayer(), "blockdoor.admin.breaktriggers"))) {
                            MyTrigger mytrig = (MyTrigger) plugin.triggerhelper.findCoordinates("MYTRIGGER", x_Pos, y_Pos, z_Pos, trig_World);
                            event.getPlayer().sendMessage("MyTrigger " + ChatColor.GREEN + mytrig.trigger_name + ChatColor.WHITE + " by " + ChatColor.GREEN + mytrig.creator + ChatColor.WHITE + " removed.");
                            dataWriter.allTriggers.remove(mytrig);
                            dataWriter.saveDatabase();
                            break startAgain;
                        }
                        else if (!mt.creator.equals(player)) {
                            event.getPlayer().sendMessage(ChatColor.RED + "You can only break your own BlockDoor triggers.");
                            event.setCancelled(true);
                            break eventCanceled;
                        }
                        else {
                            event.getPlayer().sendMessage(ChatColor.RED + "You dont have permissions to break BlockDoor triggers.");
                            event.setCancelled(true);
                            break eventCanceled;
                        }
                    }
                    else {
                        event.getPlayer().sendMessage(ChatColor.RED + "You dont have permissions to break BlockDoor triggers.");
                        event.setCancelled(true);
                        break eventCanceled;
                    }
                }
            }
        }
        if (settings.leftClick == 0) {
            triggerCount = 0;
            for(Trigger redtrig : dataWriter.allTriggers) {
                if (redtrig.trigger_Type.equals("REDTRIG") && redtrig.trigger_x == x_Pos && redtrig.trigger_y == y_Pos && redtrig.trigger_z == z_Pos && redtrig.trigger_world.equals(trig_World)) {
                    triggerCount++;
                }
            }
            eventCanceled:
            for(int i = 0; i < triggerCount; i++) {
                startAgain:
                for(Trigger r : dataWriter.allTriggers) {
                    if (r.trigger_Type.equals("REDTRIG") && r.trigger_x == x_Pos && r.trigger_y == y_Pos && r.trigger_z == z_Pos && r.trigger_world.equals(trig_World)) {
                        if (plugin.playerHasPermission(event.getPlayer(), "blockdoor.player.breaktriggers") || plugin.playerHasPermission(event.getPlayer(), "blockdoor.admin.breaktriggers")) {
                            if (r.creator.equals(event.getPlayer().getName()) || (plugin.playerHasPermission(event.getPlayer(), "blockdoor.admin.breaktriggers"))) {
                                RedTrig redtrig = (RedTrig) plugin.triggerhelper.findCoordinates("REDTRIG", x_Pos, y_Pos, z_Pos, trig_World);
                                event.getPlayer().sendMessage("Redstone Trigger " + ChatColor.GREEN + redtrig.trigger_name + ChatColor.WHITE + " by " + ChatColor.GREEN + redtrig.creator + ChatColor.WHITE + " removed.");
                                dataWriter.allTriggers.remove(redtrig);
                                dataWriter.saveDatabase();
                                break startAgain;
                            }
                            else if (!r.creator.equals(player)) {
                                event.getPlayer().sendMessage(ChatColor.RED + "You can only break your own BlockDoor triggers.");
                                event.setCancelled(true);
                                break eventCanceled;
                            }
                            else {
                                event.getPlayer().sendMessage(ChatColor.RED + "You dont have permissions to break BlockDoor triggers.");
                                event.setCancelled(true);
                                break eventCanceled;
                            }
                        }
                        else {
                            event.getPlayer().sendMessage(ChatColor.RED + "You dont have permissions to break BlockDoor triggers.");
                            event.setCancelled(true);
                            break eventCanceled;
                        }
                    }
                }
            }
        }
        else {
            settings.leftClick = 0;
            event.setCancelled(true);
        }
        int index = plugin.hdoorhelper.findCoordinates(x_Pos, y_Pos, z_Pos, trig_World);
        if (index != -1) {
            event.getPlayer().sendMessage("BlockDoor: " + ChatColor.RED + "Canceled, use " + ChatColor.WHITE + "/dhdoor " + dataWriter.hdoor.get(index).doorName + ChatColor.RED + " to edit:");
            event.getPlayer().sendMessage(ChatColor.AQUA + dataWriter.hdoor.get(index).creator + "'s " + ChatColor.RED + "Hybrid door block.");
            event.setCancelled(true);
        }
    }
}
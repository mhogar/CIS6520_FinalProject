package plugin.arcwolf.blockdoor;

import java.util.List;

import org.bukkit.entity.Entity;

import plugin.arcwolf.blockdoor.Zones.Zone;

public class AllZonesListHelper {

    private BlockDoor plugin;
    private List<AllZonesList> allZonesList;

    public AllZonesListHelper() {
        plugin = BlockDoor.plugin;
        allZonesList = plugin.datawriter.zoneOccupancyList;
    }

    public int findLiving(Zone zone, Entity in_Entity) {
        int index = -1;
        for(int i = 0; i < allZonesList.size(); i++){
            Zone z = allZonesList.get(i).zone;
            if (z == zone && allZonesList.get(i).entity == in_Entity)
                index = i;
        }
        return index;
    }

    public int countOccupants(Zone zone) {
        int count = 0;
        for(int i = 0; i < allZonesList.size(); i++){
            Zone z = allZonesList.get(i).zone;
            if (zone == z)
                count++;
        }

        return count;
    }

    public int findZonedEntity(Entity in_Entity) {
        int index = -1;
        for(int i = 0; i < allZonesList.size(); i++)
            if (allZonesList.get(i).entity == in_Entity)
                index = i;

        return index;
    }

    public int zonedEntityCount(Entity in_Entity) {
        int count = 0;
        for(int i = 0; i < allZonesList.size(); i++)
            if (allZonesList.get(i).entity == in_Entity)
                count++;

        return count;
    }
}
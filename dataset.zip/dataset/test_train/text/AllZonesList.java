package plugin.arcwolf.blockdoor;

import org.bukkit.entity.Entity;

import plugin.arcwolf.blockdoor.Zones.Zone;

//This class keeps track of all the zones and their occupants

public class AllZonesList {

    public Entity entity;
    public Zone zone;

    public AllZonesList(Zone in_Zone, Entity in_entity) {
        zone = in_Zone;
        entity = in_entity;
    }
}
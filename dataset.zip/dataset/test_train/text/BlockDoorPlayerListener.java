package plugin.arcwolf.blockdoor.listeners;

import org.bukkit.ChatColor;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import plugin.arcwolf.blockdoor.BlockDoor;
import plugin.arcwolf.blockdoor.Triggers.Trigger;
import plugin.arcwolf.blockdoor.Utils.BlockDoorSettings;
import plugin.arcwolf.blockdoor.Utils.DataWriter;
import plugin.arcwolf.blockdoor.Zones.SelectedEntityZone;
import plugin.arcwolf.blockdoor.Zones.Zone;

public class BlockDoorPlayerListener implements Listener {

    private BlockDoor plugin;
    private DataWriter dataWriter;

    public BlockDoorPlayerListener() {
        plugin = BlockDoor.plugin;
        dataWriter = plugin.datawriter;
    }

    /*
     * This function is used in the dinfo detection of zones
     * If a zone is entered the information about that zone is output to the
     * player chat box. Information includes X, Y, Z coordinates for both the
     * start and end of the zone. As well as its creator's name, the zone's name
     * and type. Also the zones world is listed.
     */

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (event.isCancelled())
            return;
        Player player = event.getPlayer();
        BlockDoorSettings settings = BlockDoorSettings.getSettings(player);

        //Work around for bug in onBlockPlaced getData() method
        if (settings.placed) {
            if (settings.stateOneIndex != -1) {
                int twoStateDoorIndex = settings.twoStateDoorIndex;
                int stateOneIndex = settings.stateOneIndex;
                int blockX = dataWriter.twostate.get(twoStateDoorIndex).stateOneContents.get(stateOneIndex).x;
                int blockY = dataWriter.twostate.get(twoStateDoorIndex).stateOneContents.get(stateOneIndex).y;
                int blockZ = dataWriter.twostate.get(twoStateDoorIndex).stateOneContents.get(stateOneIndex).z;
                int blockID = event.getPlayer().getWorld().getBlockAt(blockX, blockY, blockZ).getTypeId();
                byte blockOff = event.getPlayer().getWorld().getBlockAt(blockX, blockY, blockZ).getData();
                dataWriter.twostate.get(twoStateDoorIndex).stateOneContents.get(stateOneIndex).blockID = blockID;
                dataWriter.twostate.get(twoStateDoorIndex).stateOneContents.get(stateOneIndex).offset = blockOff;
                dataWriter.saveDatabase();
                settings.stateOneIndex = -1;
                settings.placed = false;
            }
            else if (settings.stateTwoIndex != -1) {
                int twoStateDoorIndex = settings.twoStateDoorIndex;
                int stateTwoIndex = settings.stateTwoIndex;
                int blockX = dataWriter.twostate.get(twoStateDoorIndex).stateTwoContents.get(stateTwoIndex).x;
                int blockY = dataWriter.twostate.get(twoStateDoorIndex).stateTwoContents.get(stateTwoIndex).y;
                int blockZ = dataWriter.twostate.get(twoStateDoorIndex).stateTwoContents.get(stateTwoIndex).z;
                int blockID = event.getPlayer().getWorld().getBlockAt(blockX, blockY, blockZ).getTypeId();
                byte blockOff = event.getPlayer().getWorld().getBlockAt(blockX, blockY, blockZ).getData();
                dataWriter.twostate.get(twoStateDoorIndex).stateTwoContents.get(stateTwoIndex).blockID = blockID;
                dataWriter.twostate.get(twoStateDoorIndex).stateTwoContents.get(stateTwoIndex).offset = blockOff;
                dataWriter.saveDatabase();
                settings.stateTwoIndex = -1;
                settings.placed = false;
            }
        }
        // End of work around

        if (settings.command == "info") {
            int x = player.getLocation().getBlockX();
            int y = player.getLocation().getBlockY();
            int z = player.getLocation().getBlockZ();
            int index = 0, nullCount = 0;

            for(int i = 0; i < plugin.datawriter.allZones.size(); i++) {
                if (plugin.zonehelper.findCoordinates(plugin.datawriter.allZones, x, y, z, player.getLocation().getWorld().getName()) != null && settings.select == 0) {
                    settings.select = 1;
                    Zone zone = plugin.zonehelper.findCoordinates(plugin.datawriter.allZones, x, y, z, player.getWorld().getName());

                    player.sendMessage("Found " + plugin.zonehelper.getFriendlyZoneName(zone) + " [" + ChatColor.GREEN + zone.zone_name + ChatColor.WHITE + "] Created by [" +
                            ChatColor.GREEN + zone.zone_creator + (zone instanceof SelectedEntityZone ? ChatColor.WHITE + "] Triggered by [" +
                                    ChatColor.GREEN + zone.uzone_trigger + ChatColor.WHITE + "]" : ChatColor.WHITE + "]"));
                    player.sendMessage("Starting at [X= " + ChatColor.AQUA + zone.zone_start_x + ChatColor.WHITE + " Y= " +
                            ChatColor.AQUA + zone.zone_start_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                            zone.zone_start_z + ChatColor.WHITE + "]");
                    player.sendMessage("Ending at [X= " + ChatColor.AQUA + zone.zone_end_x + ChatColor.WHITE + " Y= " +
                            ChatColor.AQUA + zone.zone_end_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                            zone.zone_end_z + ChatColor.WHITE + "] in world [" + ChatColor.AQUA +
                            zone.zone_world + ChatColor.WHITE + "]");
                    break;
                }
                if (plugin.zonehelper.findCoordinates(plugin.datawriter.allZones, x, y, z, player.getLocation().getWorld().getName()) != null)
                    break;
                nullCount++;
            }
            if (plugin.twostatedoorhelper.findCoordinates(x, y, z, player.getLocation().getWorld().getName()) != 2147483647 && settings.select == 0) {
                boolean locked = false;
                settings.select = 1;
                index = plugin.twostatedoorhelper.findCoordinates(x, y, z, player.getLocation().getWorld().getName());
                if (index < 0) {
                    index = Math.abs(index);
                    locked = true;
                }

                player.sendMessage("Found TwoState Door [" + ChatColor.GREEN + dataWriter.twostate.get(index).doorName + ChatColor.WHITE + "] Created by [" +
                        ChatColor.GREEN + dataWriter.twostate.get(index).creator + ChatColor.WHITE + "]");
                player.sendMessage("Starting at [X= " + ChatColor.AQUA + dataWriter.twostate.get(index).door_start_x + ChatColor.WHITE + " Y= " +
                        ChatColor.AQUA + dataWriter.twostate.get(index).door_start_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                        dataWriter.twostate.get(index).door_start_z + ChatColor.WHITE + "]");
                player.sendMessage("Ending at [X= " + ChatColor.AQUA + dataWriter.twostate.get(index).door_end_x + ChatColor.WHITE + " Y= " +
                        ChatColor.AQUA + dataWriter.twostate.get(index).door_end_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                        dataWriter.twostate.get(index).door_end_z + ChatColor.WHITE + "] in world [" + ChatColor.AQUA +
                        dataWriter.twostate.get(index).door_world + ChatColor.WHITE + "]");
                if (locked) {
                    player.sendMessage(ChatColor.GREEN + dataWriter.twostate.get(index).doorName + ChatColor.WHITE + " is " + ChatColor.RED + "LOCKED");
                }
                else {
                    player.sendMessage(ChatColor.GREEN + dataWriter.twostate.get(index).doorName + ChatColor.WHITE + " is " + ChatColor.GREEN + "UNLOCKED");
                }
            }
            if (plugin.zonehelper.findCoordinates(dataWriter.allZones, x, y, z, player.getLocation().getWorld().getName()) == null
                    && plugin.twostatedoorhelper.findCoordinates(x, y, z, player.getLocation().getWorld().getName()) == 2147483647
                    && settings.select == 1 && nullCount == plugin.datawriter.allZones.size()) {
                settings.select = 0;
            }
        }
    }

    /*
     * On player interact is used for splitting player interactions into the
     * proper handler functions. Right clicks are sent to the blockclicked
     * function and the players selected command is also passed. This occurs
     * only if the player has permissions.
     * Right clicking and left clicking are watched to make sure that if a
     * player is using the Redstone trigger command only right clicks are
     * accepted.
     * Left clicks while using that command are canceled to prevent
     * redstone objects from being destroyed in the process of clicking.
     */

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.isCancelled())
            return;
        Block blockClicked = event.getClickedBlock();
        Action playerClicked = event.getAction();
        Player player = event.getPlayer();
        BlockDoorSettings settings = BlockDoorSettings.getSettings(player);

        if (playerClicked == Action.RIGHT_CLICK_BLOCK && (plugin.playerHasPermission(player, "blockdoor.usetriggers") ||
                plugin.playerHasPermission(player, "*"))) {
            if (blockClicked != null) {
                blockRightClicked(player, blockClicked);
                BlockClick(player, blockClicked);
            }
        }
        else if (playerClicked == Action.LEFT_CLICK_BLOCK && settings.command == "redstonetrigger" &&
                (plugin.playerHasPermission(player, "blockdoor.usetriggers") || plugin.playerHasPermission(player, "*"))) {
            if (blockClicked != null) {
                if (blockClicked.getTypeId() == 55 || blockClicked.getTypeId() == 75 || blockClicked.getTypeId() == 76)
                    settings.leftClick = 1;
                blockRightClicked(player, blockClicked);
            }
        }
        else if (playerClicked == Action.LEFT_CLICK_BLOCK && !(settings.command == "redstonetrigger") &&
                (plugin.playerHasPermission(player, "blockdoor.usetriggers") || plugin.playerHasPermission(player, "*"))) {
            if (blockClicked != null)
                BlockClick(player, blockClicked);
        }
        //player.sendMessage("Clicked at " + blockX + ", " + blockY + ", " + blockZ);
        //player.sendMessage("playerClicked = " + playerClicked + ", command = " + settings.command + ", canUseCommand? " + BlockDoor.playerCanUseCommand(player, "*")+" "+BlockDoor.playerCanUseCommand(player, "blockdoor.usetriggers"));
    }

    /*
     * This function is used for testing if a player has teleported while a
     * command is in the process of executing.
     * 
     * Also this function handles zone teleports. If a player teleports out of a
     * zone it removes the player from that zone and reduces the occupancy count
     * by 1 per player that teleported out.
     */
    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        if (event.isCancelled())
            return;
        Player player = event.getPlayer();
        BlockDoorSettings settings = BlockDoorSettings.getSettings(player);
        if (settings.command != "") {
            plugin.commandhandler.cancelCommands(player);
            player.sendMessage(ChatColor.RED + "Teleported while BlockDoor command active. Command canceled!");
        }
    }

    /*
     * Controls the different commands a player can enter when creating or
     * toggling blockdoor objects.
     */
    private void BlockClick(Player player, Block blockClicked) {
        BlockDoorSettings settings = BlockDoorSettings.getSettings(player);
        /*
         * Better precision from getLocation().getX() than just using getX();
         * example: Player clicks -0.01X
         * blockClicked.getX() = 0X
         * blockClicked.getLocation().getX() = -1X
         */
        int blockX = (int) blockClicked.getLocation().getX();
        int blockY = (int) blockClicked.getLocation().getY();
        int blockZ = (int) blockClicked.getLocation().getZ();
        if (settings.command == "" || settings.command == "info") {
            //player.sendMessage("Looking for triggers at: " + blockX + ", " + blockY + ", " + blockZ);
            for(Trigger t : dataWriter.allTriggers) {
                if (t.trigger_Type.equals("TRIGGER") && t.coordsSet && t.trigger_x == blockX && t.trigger_y == blockY && t.trigger_z == blockZ && t.trigger_world.equals(player.getWorld().getName())) {
                    //player.sendMessage("Toggling trigger: '" + ChatColor.GREEN + t.trigger_name + ChatColor.WHITE + "'");
                    t.world = player.getWorld();
                    t.processLinks();
                }
            }
            for(Trigger mt : dataWriter.allTriggers) {
                if (mt.trigger_Type.equals("MYTRIGGER") && mt.coordsSet && mt.trigger_x == blockX && mt.trigger_y == blockY && mt.trigger_z == blockZ && mt.trigger_world.equals(player.getWorld().getName())) {
                    if (mt.creator.equals(player.getName()) || (plugin.playerHasPermission(player, "blockdoor.admin.mytrigger"))) {
                        //player.sendMessage("Toggling trigger: '" + ChatColor.GREEN + mt.trigger_name + ChatColor.WHITE + "'");
                        mt.world = player.getWorld();
                        mt.processLinks();
                    }
                    else {
                        player.sendMessage(ChatColor.YELLOW + "You toggle...but nothing happens");
                    }
                }
            }
            if (settings.command == "info") {
                infoSearch(player, blockClicked);
            }
        }
        else if (settings.command == "savestate") {
            int index = plugin.twostatedoorhelper.findCoordinates(blockX, blockY, blockZ, blockClicked.getWorld().getName());
            if (index >= 0 && index != 2147483647) {
                if (dataWriter.twostate.get(index).creator.equals(player.getName()) || (plugin.playerHasPermission(player, "blockdoor.admin.save"))) {
                    plugin.twostatedoorhelper.saveTwoState(dataWriter.twostate.get(index), player);
                    infoSearch(player, blockClicked);
                    if (dataWriter.twostate.get(index).isOpen)
                        player.sendMessage(ChatColor.GREEN + "Closed State has been saved");
                    else
                        player.sendMessage(ChatColor.GREEN + "Open State has been saved");
                }
            }
            else {
                player.sendMessage(ChatColor.RED + "No unlocked door detected");
                settings.command = "";
            }
        }
        else if (settings.command == "door") {
            plugin.singlestatedoorhelper.createDoor(settings, player, blockClicked);
        }
        else if (settings.command == "twostate") {
            plugin.twostatedoorhelper.createDoor(settings, player, blockClicked);
        }
        else if (settings.command == "trigger" || settings.command == "mytrigger") {
            plugin.triggerhelper.createTrigger(settings, player, blockClicked);
        }
        else if (settings.command == "zone" || settings.command == "myzone" || settings.command == "mzone" || settings.command == "ezone" ||
                settings.command == "azone" || settings.command == "pzone" || settings.command == "uzone")
            plugin.zonehelper.createZone(settings, player, blockClicked, settings.command == "uzone");
    }

    /*
     * Handles the redstone right click for redstone trigger creations.
     */
    private void blockRightClicked(Player player, Block blockClicked) {
        BlockDoorSettings settings = BlockDoorSettings.getSettings(player);
        plugin.redtrighelper.createRedTrig(settings, player, blockClicked);
    }

    /*
     * Used as part of the dinfo command.
     * Searches for blockdoor objects that were clicked on and displays the
     * correct information about that object.
     */
    private void infoSearch(Player player, Block blockClicked) {
        int blockX = (int) blockClicked.getLocation().getX();
        int blockY = (int) blockClicked.getLocation().getY();
        int blockZ = (int) blockClicked.getLocation().getZ();
        Trigger t = plugin.triggerhelper.findCoordinates(blockX, blockY, blockZ, blockClicked.getWorld().getName());
        int ssDoorIndex = plugin.singlestatedoorhelper.findCoordinates(blockX, blockY, blockZ, blockClicked.getWorld().getName());
        int hDoorIndex = plugin.hdoorhelper.findCoordinates(blockX, blockY, blockZ, blockClicked.getWorld().getName());
        int tsDoorIndex = plugin.twostatedoorhelper.findCoordinates(blockX, blockY, blockZ, blockClicked.getWorld().getName());
        if (t != null) {
            player.sendMessage("Found " + t.trigger_Type + " [" + ChatColor.GREEN + t.trigger_name + ChatColor.WHITE + "] Created by [" +
                    ChatColor.GREEN + t.creator + ChatColor.WHITE + "]");
            player.sendMessage("Located at [X= " + ChatColor.AQUA + t.trigger_x + ChatColor.WHITE + " Y= " +
                    ChatColor.AQUA + t.trigger_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                    t.trigger_z + ChatColor.WHITE + "] in world [" + ChatColor.AQUA +
                    t.trigger_world + ChatColor.WHITE + "]");
        }
        else if (ssDoorIndex != -1) {
            player.sendMessage("Found Door [" + ChatColor.GREEN + dataWriter.doors.get(ssDoorIndex).doorName + ChatColor.WHITE + "] Created by [" +
                    ChatColor.GREEN + dataWriter.doors.get(ssDoorIndex).creator + ChatColor.WHITE + "]");
            player.sendMessage("Starting at [X= " + ChatColor.AQUA + dataWriter.doors.get(ssDoorIndex).door_start_x + ChatColor.WHITE + " Y= " +
                    ChatColor.AQUA + dataWriter.doors.get(ssDoorIndex).door_start_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                    dataWriter.doors.get(ssDoorIndex).door_start_z + ChatColor.WHITE + "]");
            player.sendMessage("Ending at [X= " + ChatColor.AQUA + dataWriter.doors.get(ssDoorIndex).door_end_x + ChatColor.WHITE + " Y= " +
                    ChatColor.AQUA + dataWriter.doors.get(ssDoorIndex).door_end_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                    dataWriter.doors.get(ssDoorIndex).door_end_z + ChatColor.WHITE + "] in world [" + ChatColor.AQUA +
                    dataWriter.doors.get(ssDoorIndex).door_world + ChatColor.WHITE + "]");
        }
        else if (hDoorIndex != -1) {
            player.sendMessage("Found Hybrid Door [" + ChatColor.GREEN + dataWriter.hdoor.get(hDoorIndex).doorName + ChatColor.WHITE + "] Created by [" +
                    ChatColor.GREEN + dataWriter.hdoor.get(hDoorIndex).creator + ChatColor.WHITE + "]");
            player.sendMessage("Located at [X= " + ChatColor.AQUA + blockX + ChatColor.WHITE + " Y= " +
                    ChatColor.AQUA + blockY + ChatColor.WHITE + " Z= " + ChatColor.AQUA + blockZ + ChatColor.WHITE + "] in world ["
                    + ChatColor.AQUA + dataWriter.hdoor.get(hDoorIndex).door_world + ChatColor.WHITE + "]");
        }
        else if (tsDoorIndex != 2147483647) {
            boolean locked = false;
            if (tsDoorIndex < 0) {
                tsDoorIndex = Math.abs(tsDoorIndex);
                locked = true;
            }
            player.sendMessage("Found TwoState Door [" + ChatColor.GREEN + dataWriter.twostate.get(tsDoorIndex).doorName + ChatColor.WHITE + "] Created by [" +
                    ChatColor.GREEN + dataWriter.twostate.get(tsDoorIndex).creator + ChatColor.WHITE + "]");
            player.sendMessage("Starting at [X= " + ChatColor.AQUA + dataWriter.twostate.get(tsDoorIndex).door_start_x + ChatColor.WHITE + " Y= " +
                    ChatColor.AQUA + dataWriter.twostate.get(tsDoorIndex).door_start_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                    dataWriter.twostate.get(tsDoorIndex).door_start_z + ChatColor.WHITE + "]");
            player.sendMessage("Ending at [X= " + ChatColor.AQUA + dataWriter.twostate.get(tsDoorIndex).door_end_x + ChatColor.WHITE + " Y= " +
                    ChatColor.AQUA + dataWriter.twostate.get(tsDoorIndex).door_end_y + ChatColor.WHITE + " Z= " + ChatColor.AQUA +
                    dataWriter.twostate.get(tsDoorIndex).door_end_z + ChatColor.WHITE + "] in world [" + ChatColor.AQUA +
                    dataWriter.twostate.get(tsDoorIndex).door_world + ChatColor.WHITE + "]");
            if (locked) {
                player.sendMessage(ChatColor.GREEN + dataWriter.twostate.get(tsDoorIndex).doorName + ChatColor.WHITE + " is " + ChatColor.RED + "LOCKED");
            }
            else {
                player.sendMessage(ChatColor.GREEN + dataWriter.twostate.get(tsDoorIndex).doorName + ChatColor.WHITE + " is " + ChatColor.GREEN + "UNLOCKED");
            }
        }
        else {
            player.sendMessage("No blockdoor object found at [x=" + ChatColor.GREEN + blockX + ChatColor.WHITE + " y=" +
                    ChatColor.GREEN + blockY + ChatColor.WHITE + " z=" + ChatColor.GREEN + blockZ + ChatColor.WHITE + "]");
            //player.sendMessage("Item Clicked is " + blockClicked.getTypeId() + " " + blockClicked.getType());
        }
    }
}